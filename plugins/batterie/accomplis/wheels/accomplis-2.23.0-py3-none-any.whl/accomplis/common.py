"""
Shared utilities for Todoist CLI tools.

Provides common functions used across cli.py and flatten.py:
- API client with timeout and retry
- Pagination helpers
- Project/section resolution
- Object serialization
"""

import random
import sys
import time
from typing import Any, Callable

# Lazy imports to allow --help without SDK installed
TodoistAPI = None

# Configuration
DEFAULT_TIMEOUT = 30  # seconds to read a response
CONNECT_TIMEOUT = 10  # seconds to open a connection
RATE_LIMIT_DELAY = 0.2  # seconds between API calls
MAX_RETRIES = 3
RETRY_BACKOFF_BASE = 1.0  # seconds; doubles per retry, plus jitter
RETRY_AFTER_CAP = 30  # seconds; ceiling on server-requested Retry-After waits
RETRY_BUDGET = 60  # seconds; total wall time one request may spend retrying


def _env_number(name: str, default, cast):
    import os

    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    try:
        return cast(raw)
    except ValueError:
        print(f"Warning: ignoring {name}={raw!r} (not a number); using {default}", file=sys.stderr)
        return default


def retry_settings() -> dict:
    """Retry knobs, read from the environment at client build time.

    ACCOMPLIS_FAST_FAIL=1 is for loop callers that would rather fail now and
    retry next cycle (accomplis-fafaba): one retry, 5 s budget, 5 s timeouts.
    ACCOMPLIS_MAX_RETRIES and ACCOMPLIS_RETRY_BUDGET override either profile.
    """
    import os

    fast = os.environ.get("ACCOMPLIS_FAST_FAIL", "") not in ("", "0")
    return {
        "max_retries": max(0, _env_number("ACCOMPLIS_MAX_RETRIES", 1 if fast else MAX_RETRIES, int)),
        "budget": max(0.0, _env_number("ACCOMPLIS_RETRY_BUDGET", 5 if fast else RETRY_BUDGET, float)),
        "connect_timeout": 5 if fast else CONNECT_TIMEOUT,
        "read_timeout": 5 if fast else DEFAULT_TIMEOUT,
    }

# Which (method, status) pairs are safe to replay. 429 and 503 mean the request
# was rejected before processing (rate limit / load shedding), so any method can
# retry. 500/502/504 can arrive after the origin processed the request — a
# replayed POST there could double-create a task — so only idempotent methods
# retry on those.
_RETRY_ANY_METHOD = {429, 503}
_RETRY_IDEMPOTENT_ONLY = {500, 502, 504}
_IDEMPOTENT_METHODS = {"GET", "HEAD", "OPTIONS", "PUT", "DELETE"}


def _should_retry(method: str, status: int) -> bool:
    if status in _RETRY_ANY_METHOD:
        return True
    return status in _RETRY_IDEMPOTENT_ONLY and method.upper() in _IDEMPOTENT_METHODS


def _retry_wait(retry_after: str | None, backoff: float) -> tuple[float, str]:
    """(seconds, reason): server-directed Retry-After when present (capped), else backoff+jitter."""
    if retry_after:
        try:
            asked = float(retry_after)
            if asked > RETRY_AFTER_CAP:
                return RETRY_AFTER_CAP, f"Retry-After {asked:.0f}s, capped"
            return asked, "Retry-After"
        except ValueError:
            pass  # HTTP-date form or garbage — fall back to backoff
    return backoff + random.uniform(0, backoff / 2), "backoff"


def make_retry_transport(inner=None, sleep=time.sleep, clock=time.monotonic,
                         max_retries=None, budget=None):
    """
    httpx transport that retries transient Todoist failures, out loud.

    Retries (tgt-radaji): 429/503 on any method; 500/502/504 on idempotent
    methods only; connection failures on any method (the request never left);
    read timeouts on idempotent methods. 4xx bar 429 never retries — a 401
    must fail loudly and fast.

    Every retry prints one stderr line: attempt n of m, why, how long it will
    wait and how much of the budget is spent. The budget caps the total wall
    time one request may spend across attempts and waits, so a caller never
    sits minutes in silence (accomplis-cuwuza). Connection retries used to
    happen silently inside httpx.HTTPTransport(retries=3); they are ours now.

    `inner`, `sleep` and `clock` are injectable for tests.
    """
    import httpx

    settings = retry_settings()
    max_retries = settings["max_retries"] if max_retries is None else max(0, max_retries)
    budget = settings["budget"] if budget is None else budget
    attempts = max_retries + 1

    def say(msg):
        print(f"  ⏳ {msg}", file=sys.stderr)

    class _RetryTransport(httpx.BaseTransport):
        def __init__(self):
            self._inner = inner or httpx.HTTPTransport(retries=0)

        def handle_request(self, request):
            request.read()  # materialise the body so a replay resends it
            backoff = RETRY_BACKOFF_BASE
            started = clock()
            where = f"{request.method} {request.url.path}"
            idempotent = request.method.upper() in _IDEMPOTENT_METHODS
            for attempt in range(1, attempts + 1):
                try:
                    response = self._inner.handle_request(request)
                except (httpx.ConnectError, httpx.ConnectTimeout) as e:
                    failure, error, response = f"could not connect ({type(e).__name__})", e, None
                except (httpx.ReadTimeout, httpx.ReadError, httpx.WriteError,
                        httpx.RemoteProtocolError) as e:
                    if not idempotent:
                        raise  # the server may have acted on it; never replay
                    failure, error, response = f"no response ({type(e).__name__})", e, None
                else:
                    if not _should_retry(request.method, response.status_code):
                        return response
                    failure, error = f"Todoist {response.status_code}", None

                retry_after = response.headers.get("Retry-After") if response is not None else None
                wait, why = _retry_wait(retry_after, backoff)
                spent = clock() - started

                if attempt == attempts or spent + wait > budget:
                    reason = ("no retries left" if attempt == attempts
                              else f"next wait {wait:.1f}s would pass the {budget:.0f}s retry budget")
                    say(f"{failure} on {where}: attempt {attempt} of {attempts} failed; "
                        f"giving up ({reason}, {spent:.0f}s spent)")
                    if error is not None:
                        raise error
                    return response

                if response is not None:
                    response.close()
                say(f"{failure} on {where}: attempt {attempt} of {attempts} failed; "
                    f"retrying in {wait:.1f}s ({why}; {spent:.0f}s of {budget:.0f}s budget spent)")
                sleep(wait)
                backoff *= 2
            raise AssertionError("unreachable: the loop returns or raises on its last attempt")

        def close(self):
            self._inner.close()

    return _RetryTransport()


def _build_client():
    """httpx.Client with timeout, connection retries, and transient-status retries."""
    import httpx

    settings = retry_settings()
    timeout = httpx.Timeout(settings["read_timeout"], connect=settings["connect_timeout"])
    return httpx.Client(timeout=timeout, transport=make_retry_transport())


def get_api():
    """
    Get authenticated TodoistAPI instance with timeout and retry.

    todoist-api-python v4 switched from requests to httpx internally.
    We pass an httpx.Client with timeout and retry transport.
    """
    global TodoistAPI
    if TodoistAPI is None:
        try:
            from todoist_api_python.api import TodoistAPI as API
            TodoistAPI = API
        except ImportError:
            print("Error: todoist-api-python not installed", file=sys.stderr)
            print("\nInstall with: pip install todoist-api-python", file=sys.stderr)
            sys.exit(1)

    from accomplis.token_store import get_token

    token = get_token()
    return TodoistAPI(token, client=_build_client())


def fetch_task_raw(api, task_id: str) -> dict:
    """GET /api/v1/tasks/{id} as raw JSON, for fields the SDK's Task drops.

    The SDK model has no is_deleted, so a deleted task fetched by id renders
    as live (accomplis-kudajo). Rides the api's own client, so the timeout and
    loud retries apply. Raises httpx.HTTPStatusError like the SDK does.
    """
    resp = api._client.get(
        f"https://api.todoist.com/api/v1/tasks/{task_id}",
        headers={"Authorization": f"Bearer {api._token}"},
    )
    resp.raise_for_status()
    return resp.json()


def get_current_user() -> dict:
    """
    Get the current authenticated user from Todoist REST API v1.

    Calls GET /api/v1/user directly (not wrapped by the SDK).
    Returns dict with id, full_name, email, and other user fields.
    """
    from accomplis.token_store import get_token

    token = get_token()
    with _build_client() as client:
        resp = client.get(
            "https://api.todoist.com/api/v1/user",
            headers={"Authorization": f"Bearer {token}"},
        )
    resp.raise_for_status()
    return resp.json()


def collect_paginated(iterator) -> list:
    """Collect all items from a paginated SDK iterator."""
    items = []
    for batch in iterator:
        items.extend(batch)
    return items


def to_dict(obj: Any) -> dict:
    """Convert SDK object to dict for JSON output."""
    if hasattr(obj, 'to_dict'):
        return obj.to_dict()
    if hasattr(obj, '__dict__'):
        return {k: v for k, v in obj.__dict__.items() if not k.startswith('_')}
    return obj


def resolve_project(api, name_or_id: str) -> str:
    """
    Resolve a project name to ID.

    Returns project ID string. Exits with error if not found.
    """
    projects = collect_paginated(api.get_projects())
    name_lower = name_or_id.lower()

    # Try name lookup
    for p in projects:
        if p.name.lower() == name_lower:
            return p.id

    # Try ID lookup
    for p in projects:
        if p.id == name_or_id:
            return p.id

    # Not found - show available projects
    available = sorted([p.name for p in projects])
    print(f"Error: Project '{name_or_id}' not found", file=sys.stderr)
    print(f"Available projects: {', '.join(available[:10])}", file=sys.stderr)
    if len(available) > 10:
        print(f"  ...and {len(available) - 10} more", file=sys.stderr)
    print("\n⚠️  STOP: Load the accomplis skill before using this CLI!", file=sys.stderr)
    sys.exit(1)


def resolve_project_object(api, name_or_id: str):
    """
    Resolve a project name or ID to the full Project object.

    Returns the SDK Project object. Exits with error if not found.
    """
    projects = collect_paginated(api.get_projects())
    name_lower = name_or_id.lower()

    for p in projects:
        if p.name.lower() == name_lower:
            return p

    for p in projects:
        if p.id == name_or_id:
            return p

    print(f"Error: Project '{name_or_id}' not found", file=sys.stderr)
    sys.exit(1)


def resolve_section(api, project_id: str, name_or_id: str) -> str:
    """
    Resolve a section name to ID within a project.

    Returns section ID string. Exits with error if not found.
    """
    sections = collect_paginated(api.get_sections(project_id=project_id))
    name_lower = name_or_id.lower()

    # Try name lookup
    for s in sections:
        if s.name.lower() == name_lower:
            return s.id

    # Try ID lookup
    for s in sections:
        if s.id == name_or_id:
            return s.id

    # Not found - show available sections
    available = [s.name for s in sections]
    print(f"Error: Section '{name_or_id}' not found in project", file=sys.stderr)
    if available:
        print(f"Available sections: {', '.join(available)}", file=sys.stderr)
    else:
        print("This project has no sections.", file=sys.stderr)
    print("\n⚠️  STOP: Load the accomplis skill before using this CLI!", file=sys.stderr)
    sys.exit(1)


def resolve_assignee(api, project_id: str, name_email_or_id: str) -> str:
    """Resolve an assignee to a user ID.

    Accepts a name (exact, then unique substring), an email, or the numeric id
    that `accomplis collaborators` emits — the tool's own output must round-trip
    into its own filter (tgt-husule).
    """
    collaborators = collect_paginated(api.get_collaborators(project_id))
    needle = name_email_or_id.lower()

    for c in collaborators:
        if (c.name.lower() == needle
                or c.email.lower() == needle
                or str(c.id) == name_email_or_id):
            return c.id

    partial = [c for c in collaborators if needle in c.name.lower()]
    if len(partial) == 1:
        return partial[0].id
    if len(partial) > 1:
        names = ", ".join(c.name for c in partial)
        print(f"Error: '{name_email_or_id}' matches several collaborators: {names}",
              file=sys.stderr)
        sys.exit(1)

    available = ", ".join(f"{c.name} <{c.email}> ({c.id})" for c in collaborators)
    print(f"Error: Collaborator '{name_email_or_id}' not found in project.",
          file=sys.stderr)
    print(f"Accepts name, email, or id. Available: {available or 'none — project has no collaborators'}",
          file=sys.stderr)
    sys.exit(1)


def api_call_with_retry(func: Callable, *args, **kwargs) -> Any:
    """
    Pace a call in a loop of writes (a short sleep before each).

    Retrying lives in the transport (make_retry_transport), which retries out
    loud within a budget. This used to retry 429s a second time on top of that,
    stacking two silent-ish layers into multi-minute stalls (accomplis-cuwuza).
    """
    time.sleep(RATE_LIMIT_DELAY)
    return func(*args, **kwargs)


def handle_task_not_found(e: Exception, task_id: str):
    """Handle task not found errors with clean message."""
    error_str = str(e).lower()
    # Todoist returns 400 for invalid IDs, 404 for valid-format but missing
    if "404" in error_str or "not found" in error_str or "400" in error_str:
        print(f"Error: Task '{task_id}' not found or invalid", file=sys.stderr)
        sys.exit(1)
    # Re-raise if it's a different error
    raise
