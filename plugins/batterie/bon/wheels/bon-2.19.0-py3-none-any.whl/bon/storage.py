"""Storage operations for bon items."""
import contextlib
import copy
import fcntl
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from bon.ids import get_siblings

# Known updated_by verbs, used by cmd_doctor for validation
KNOWN_VERBS = frozenset({
    "edited", "waited", "unwaited", "worked", "stepped",
    "cleared", "archived", "converted", "reopened", "reclaimed",
    "moved", "parked", "unparked", "released", "repaired", "restored",
    # bon-fobahe: verbs that used to change items without restamping them
    "done", "noted", "unblocked", "reordered", "reparented",
})

# The message in a bottle: written into every board so an agent with none of
# our tooling (no plugin, no CLI, any vendor) knows how to read and write it.
# Vehicle-neutral by contract (docs/CONTRACT.md non-goals) — no harness-specific
# text. Git-tracked, unlike the prefix/backend markers: travelling with clones
# is its entire job.
BOARD_README = """\
# This is a bon board

This directory is a work tracker ("bon") used by human–AI partnerships.
It is the durable work memory for this repository: **outcomes** (desired
results) and **actions** (concrete steps), each carrying a brief —
why / what / done, plus optional how.

Everything an agent needs to work with it safely is below.
Tool and docs: https://github.com/spm1001/bon

## Reading (safe from any surface)

- `items.jsonl` — one self-describing JSON object per line. Key fields:
  `id`, `type` (outcome|action), `title`, `brief{why,how,what,done}`,
  `status` (open|done), `parent`, `waiting_for` (list of blocker ids),
  `someday` (revisit condition — item is parked, not ready).
- "Ready" = status open, empty/absent `waiting_for`, no `someday` (own or
  parent's).
- An id from an old commit or handoff that isn't in `items.jsonl` may have
  been renamed: `aliases.jsonl` maps each old id (`old`) to its current one
  (`new`). Ids are never reused, so the mapping is safe to follow.
- If `.bon/backend` contains `dolt`, this clone predates the board's move
  into the repo (Dolt was retired on 2026-10-24): `git pull` to get it.
- Best orientation: read `understanding.md` and the newest handoff in
  `handoffs/` — each lives either in this directory or visibly at the
  repo/room root.

## Writing (through the tool, never by hand)

- With the CLI (the batterie plugin installs it:
  `claude plugin install batterie@batterie`):
  `bon list`, `bon show ID`, pipe JSON to `bon new`, `bon done ID --note`.
- Without the CLI: leave `items.jsonl` untouched. Append a `### Candidates`
  section to your session's handoff instead, proposing changes as
  provenance-tagged NEW/DONE/EDIT entries — the next tool-bearing session
  applies ("mints") them. Format:
  https://github.com/spm1001/bon/blob/main/docs/HANDOFF-CONTRACT.md
- Hand-edits break invariants the tool maintains: ID uniqueness, dedup,
  the blocker-release cascade, and merge semantics.
"""


# What a stale clone is told — one still carrying .bon/backend=dolt, or a
# half-pulled one (bon-famuwi). The fallback is measured: bon's bottle refresh
# leaves .bon/README.md modified in about half the old Dolt clones (9 of 18 on
# tube, 2026-09-25), and a pull refuses.
PULL_THE_MOVE = (
    "  git pull in the board's repo — that removes .bon/backend and brings "
    "items.jsonl — then re-run.\n"
    "  If the pull refuses over .bon/README.md, .bon/items.jsonl or "
    ".bon/archive.jsonl, the local copy is stale: discard it "
    "(git checkout -- <file>, or rm it if untracked) and pull again.\n"
)


class ValidationError(Exception):
    """Raised when item validation fails."""
    pass


class BonError(Exception):
    """Raised by error() for user-facing errors."""
    pass


def error(message: str) -> None:
    """Raise BonError with the given message."""
    raise BonError(message)


def warn(message: str) -> None:
    """Print warning message to stderr (does not exit)."""
    print(f"Warning: {message}", file=sys.stderr)


def refresh_bottle(bon_dir: Path) -> bool:
    """Bring a board's README.md (the bottle) to current BOARD_README wording.

    Returns True when it wrote — the file was missing or carried stale
    wording. The bottle is machine-owned: 29+ static copies shipped in the
    2026-07-21 backfill, so this is the single code path that converges them.
    """
    path = Path(bon_dir) / "README.md"
    if path.exists() and path.read_text() == BOARD_README:
        return False
    path.write_text(BOARD_README)
    return True


def _refresh_bottle_quietly(bon_dir: Path) -> None:
    """Refresh the bottle on the back of a save, like repos-table registration.

    A refresh failure must never break the save it rides.
    """
    with contextlib.suppress(OSError):
        refresh_bottle(bon_dir)


_cached_data_dir: Path | None = None


def _find_bon_dir() -> Path | None:
    """Walk up from CWD to find an existing .bon directory.

    Mirrors git rev-parse semantics: check each directory from CWD upward,
    stopping at a .git boundary (a nested repo without its own board must
    not adopt an outer repo's). At CWD any .bon directory counts; above it
    only a real board does — one with a prefix file — so bare handoff
    stashes like ~/.bon are never adopted on the way up.
    """
    cur = Path.cwd().resolve()
    for directory in (cur, *cur.parents):
        bon = directory / ".bon"
        if bon.is_dir():
            if directory == cur or (bon / "prefix").is_file():
                return bon
            # A cloned repo can carry knowledge files while its local
            # markers were gitignored — adopt it so check_initialized can
            # name the real problem instead of "Not initialized".
            if (directory / ".git").exists() and _looks_like_cloned_board(bon):
                return bon
        if (directory / ".git").exists():
            return None
    return None


def _looks_like_cloned_board(bon: Path) -> bool:
    """True when a .bon has git-tracked knowledge files but no prefix marker."""
    if (bon / "prefix").is_file():
        return False
    return (bon / "handoffs").is_dir() or (bon / "understanding.md").is_file()


def _derive_prefix_from_items(items_file: Path) -> str | None:
    """Best-effort board prefix from item IDs (everything before the LAST '-').

    A board's items all share its prefix, so the first parseable id suffices.
    Returns None when the file is unreadable or has no usable id.
    """
    try:
        with items_file.open() as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    item = json.loads(line)
                except json.JSONDecodeError:
                    continue
                item_id = item.get("id", "")
                if "-" in item_id:
                    return item_id.rsplit("-", 1)[0]
    except OSError:
        return None
    return None


def _data_dir() -> Path:
    """Return the data directory as an absolute path.

    Walks up from CWD (stopping at a .git boundary) so subdirectory
    sessions find their repo's board; falls back to ./.bon when no board
    exists yet (pre-init). Caches on first call, so CWD changes
    mid-process can't cause reads/writes to target the wrong directory.
    """
    global _cached_data_dir
    if _cached_data_dir is not None:
        return _cached_data_dir

    _cached_data_dir = _find_bon_dir() or Path(".bon").resolve()
    return _cached_data_dir


def _reset_data_dir() -> None:
    """Reset cached data dir. For tests only."""
    global _cached_data_dir
    _cached_data_dir = None


# Dolt was retired on 2026-10-24 (bon-bozocu, bon-sujeno): every board is
# .bon/items.jsonl in its own repo. A clone still carrying .bon/backend=dolt
# hasn't pulled the migrate commit, and pulling is the whole fix.
DOLT_RETIRED = (
    "this clone still says .bon/backend=dolt, but Dolt was retired on 2026-10-24:\n"
    "every bon board now lives in its repo as .bon/items.jsonl. Pull the repo:\n"
    "  git pull\n"
    "(if the pull refuses because .bon/README.md is modified, run\n"
    "`git checkout -- .bon/README.md` first — bon rewrote it, nothing is lost)."
)


def _is_stale_dolt_clone(bon_dir: Path) -> bool:
    backend_file = Path(bon_dir) / "backend"
    return backend_file.is_file() and backend_file.read_text().strip().lower() == "dolt"


def check_not_stale_dolt_clone(bon_dir: Path | None = None) -> None:
    """Refuse, naming `git pull`, in a clone that predates its board's move."""
    if _is_stale_dolt_clone(bon_dir or _data_dir()):
        error(DOLT_RETIRED)


def items_path() -> Path:
    """Return the path to items.jsonl."""
    return _data_dir() / "items.jsonl"


def _most_recent_timestamp(item: dict) -> str:
    """Return the most recent timestamp from an item for dedup comparison."""
    return (item.get("done_at") or item.get("archived_at")
            or item.get("updated_at") or item.get("created_at") or "")


def _normalise_waiting_for(items: list[dict]) -> list[dict]:
    """Normalise waiting_for from legacy string to list format.

    After this, waiting_for is always list[str] or None.
    """
    for item in items:
        wf = item.get("waiting_for")
        if isinstance(wf, str):
            item["waiting_for"] = [wf]
        elif wf is not None and not isinstance(wf, list):
            item["waiting_for"] = None
    return items


def load_items() -> list[dict]:
    """Load all items from items.jsonl with validation.

    Deduplicates by ID, preferring the version with the most recent timestamp
    (done_at > archived_at > updated_at > created_at). This handles union merge artifacts where git keeps
    both old and new versions of an edited line.
    """
    check_not_stale_dolt_clone()
    return _load_items_jsonl(_data_dir() / "items.jsonl")


# Board state as loaded, keyed by items.jsonl path. The git sync's
# item-grain merge diffs a save against this, so a write after a rebase
# can't clobber items another clone changed (the resena lesson at git
# grain). Deep-copied: cli.py mutates the loaded dicts in place.
_LOAD_SNAPSHOTS: dict[str, list[dict]] = {}


def _load_items_jsonl(path: Path, record_snapshot: bool = True) -> list[dict]:
    """Parse, validate, and dedup a specific items.jsonl file."""
    if not path.exists():
        if record_snapshot:
            _LOAD_SNAPSHOTS[str(path)] = []
        return []

    seen: dict[str, dict] = {}  # id -> item (best version wins)
    duplicates: set[str] = set()
    for line_num, line in enumerate(path.read_text().splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        # Detect git conflict markers
        if line.startswith(("<<<<<<", "======", ">>>>>>")):
            print(
                f"Warning: Git conflict marker on line {line_num} — "
                f"resolve merge conflicts in {path}",
                file=sys.stderr,
            )
            continue
        try:
            item = json.loads(line)
            validate_item(item)
            item_id = item["id"]
            if item_id in seen:
                duplicates.add(item_id)
                # Keep the version with the most recent timestamp
                if _most_recent_timestamp(item) >= _most_recent_timestamp(seen[item_id]):
                    seen[item_id] = item
            else:
                seen[item_id] = item
        except (json.JSONDecodeError, ValidationError) as e:
            print(f"Warning: Skipping malformed item on line {line_num}: {e}", file=sys.stderr)

    if duplicates:
        ids = ", ".join(sorted(duplicates))
        print(
            f"Warning: Duplicate IDs found (merge artifact?): {ids}",
            file=sys.stderr,
        )

    result = _normalise_waiting_for(list(seen.values()))
    if record_snapshot:
        _LOAD_SNAPSHOTS[str(path)] = copy.deepcopy(result)
    return result


def validate_item(item: dict, strict: bool = False) -> None:
    """Validate item has required fields. Raises ValidationError if invalid.

    Args:
        item: The item to validate
        strict: If True, also validates brief subfields (used for bon edit).
                If False, lenient validation for loading potentially old data.
    """
    required = ["id", "type", "title", "status"]
    for field in required:
        if field not in item:
            raise ValidationError(f"Missing required field: {field}")

    if item["type"] not in ("outcome", "action"):
        raise ValidationError(f"Invalid type: {item['type']}")

    if item["status"] not in ("open", "done"):
        raise ValidationError(f"Invalid status: {item['status']}")

    if strict:
        # Brief must exist and have all subfields
        if "brief" not in item:
            raise ValidationError("Missing required field: brief")
        brief = item.get("brief", {})
        for subfield in ["why", "what", "done"]:
            if subfield not in brief:
                raise ValidationError(f"Missing brief.{subfield}")


# Per-board write lock (bon-beneba). Two bon processes on one clone each
# load, mutate and rewrite the whole file; without a lock the later writer's
# snapshot predates the earlier one's change and deletes it (measured on the
# ~/.claude carte board, 2026-09-01). The lock file lives outside the repo so
# it never shows as untracked (gitsync reads an untracked file as a dirty
# tree). Reentrant within a process: flock on a second fd of the same file
# would block its own holder.
_LOCK_TIMEOUT = 90.0  # a holder now pushes too: fetch + up to three push rounds
_HELD_LOCKS: dict[str, list] = {}


def _lock_path(bon_dir: Path) -> Path:
    cache = Path(os.environ.get("XDG_CACHE_HOME") or Path.home() / ".cache")
    key = hashlib.sha1(str(bon_dir.resolve()).encode()).hexdigest()[:16]
    return cache / "bon" / "locks" / f"{key}.lock"


@contextlib.contextmanager
def _board_lock(bon_dir: Path):
    key = str(bon_dir.resolve())
    held = _HELD_LOCKS.get(key)
    if held:
        held[1] += 1
        try:
            yield
        finally:
            held[1] -= 1
        return
    lock_file = _lock_path(bon_dir)
    lock_file.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(lock_file, os.O_RDWR | os.O_CREAT, 0o600)
    deadline = time.monotonic() + _LOCK_TIMEOUT
    try:
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() > deadline:
                    error(
                        f"Another bon process has held this board's write lock for "
                        f"{int(_LOCK_TIMEOUT)}s ({bon_dir}). Nothing was written. "
                        f"If no bon command is running, delete {lock_file} and retry."
                    )
                time.sleep(0.05)
        _HELD_LOCKS[key] = [fd, 1]
        try:
            yield
        finally:
            del _HELD_LOCKS[key]
            fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        os.close(fd)


def _reconcile_with_disk(path: Path, items: list[dict]) -> list[dict]:
    """Merge this write with the file as it stands, at item grain.

    Must run under _board_lock. Base is the board as this process loaded it;
    anything another process changed since then is kept, and an item both
    changed refuses loudly before anything is written. A save with no prior
    load (migrate, import) is a deliberate whole-board population: ours wins.
    """
    snapshot = _LOAD_SNAPSHOTS.get(str(path))
    if snapshot is None:
        return canonicalise_at(path.parent, items)
    # A sibling process may have re-prefixed the board since we loaded it:
    # put all three sides in current ids before comparing (bon-poboso).
    canon = lambda xs: canonicalise_at(path.parent, xs)  # noqa: E731
    items, snapshot = canon(items), canon(snapshot)
    theirs = canon(_load_items_jsonl(path, record_snapshot=False))
    if theirs == snapshot:
        return items
    from bon.gitsync import merge_items
    merged, conflicts = merge_items(snapshot, items, theirs)
    if conflicts:
        error(
            "Another bon process changed the same item(s) since this command "
            f"loaded the board: {', '.join(conflicts)}.\n"
            "This command's change was NOT applied. Check with `bon show <id>`, "
            "then re-run it against the fresh board."
        )
    return merged


def _half_pulled_message(bon_dir: Path) -> str:
    # Two causes: a stale clone (the pull fixes it) or a hand deletion of
    # .bon/backend on a board that never moved. No route
    # commits items.jsonl: that would publish a stray as the board.
    return (
        "Refusing to write: this clone is half-pulled. .bon/backend is gone from "
        "disk, but git still tracks it (backend=dolt) and does not track "
        ".bon/items.jsonl, so a write here would start a second board that "
        "nothing reads. Nothing was written.\n"
        + PULL_THE_MOVE
        + "  If `git pull` succeeds and the clone is still in this shape, the board "
        "never moved: restore it with git checkout HEAD -- .bon/backend."
    )


def _refuse_if_half_pulled(bon_dir: Path) -> None:
    """bon-famuwi: every board write calls it before touching the board, the
    bottle or the lock — and the stale-clone refusal with it."""
    check_not_stale_dolt_clone(Path(bon_dir))
    from bon.gitsync import unpulled_move
    if unpulled_move(bon_dir):
        error(_half_pulled_message(bon_dir))


def _write_board_jsonl(path: Path, items: list[dict]) -> None:
    """Sync, reconcile, write, commit and push a JSONL board, all under its lock.

    finalize() stays inside the lock: its push-retry loop rebases and may rewrite
    items.jsonl, and a sibling reconciling against that file mid-rebase wrote a stale
    board back — 1 of 132 concurrent writes silently lost in the 2026-09-27 replay
    (four processes on one clone, two on another), printed as a clean success."""
    _refuse_if_half_pulled(path.parent)
    with _board_lock(path.parent):
        ctx = _presync_jsonl(path, items)
        if ctx is not None:
            items = ctx[1]
        items = _reconcile_with_disk(path, items)
        _canonicalise_archive_at(path.parent)
        items = _drop_archived_twins(path.parent, items)
        _save_items_jsonl(path, items)
        _LOAD_SNAPSHOTS[str(path)] = copy.deepcopy(_load_items_jsonl(path, record_snapshot=False))
        if ctx is not None:
            from bon.gitsync import finalize
            finalize(ctx[0])
    _refresh_bottle_quietly(path.parent)


def save_items(items: list[dict]) -> None:
    """Save items atomically, sorted by ID for deterministic output.

    Deduplicates by ID before writing, keeping the version with the most
    recent timestamp. This prevents duplicate lines from any source
    (migrate, manual edits, agent mistakes).

    Deterministic order means two branches that touch different items
    produce minimal diffs, enabling clean git merges.
    """
    _write_board_jsonl(_data_dir() / "items.jsonl", items)


def _presync_jsonl(path: Path, items: list[dict]):
    """Run the git sync's pre-write pass for a JSONL board (bon-guritu).

    Returns (ctx, items_to_write) when sync engages, else None. A
    same-item conflict raises BonError here — before anything is written,
    so neither side's edit is silently dropped. Any other sync failure
    degrades to an unsynced save: losing the sync must never lose the
    write.
    """
    from bon.gitsync import prepare, presync
    try:
        ctx = prepare(path)
        if ctx is None:
            return None
        merged = presync(
            ctx, items, _LOAD_SNAPSHOTS.get(str(path)),
            lambda: _load_items_jsonl(path, record_snapshot=False),
            canon=lambda xs: canonicalise_at(path.parent, xs),
        )
        return (ctx, merged)
    except BonError:
        raise
    except (OSError, subprocess.SubprocessError) as e:
        warn(f"board sync: skipped ({e}) — saving locally.")
        return None


def _save_items_jsonl(path: Path, items: list[dict]) -> None:
    """Dedup and atomically write items to a specific items.jsonl file."""
    seen: dict[str, dict] = {}
    duplicates: set[str] = set()
    for item in items:
        item_id = item.get("id", "")
        if item_id in seen:
            duplicates.add(item_id)
            if _most_recent_timestamp(item) >= _most_recent_timestamp(seen[item_id]):
                seen[item_id] = item
        else:
            seen[item_id] = item

    if duplicates:
        ids = ", ".join(sorted(duplicates))
        print(f"Warning: Deduplicated IDs on save: {ids}", file=sys.stderr)

    tmp = path.with_suffix(".tmp")

    with open(tmp, "w") as f:
        for item in sorted(seen.values(), key=lambda i: i.get("id", "")):
            f.write(json.dumps(item, ensure_ascii=False) + "\n")

    tmp.rename(path)  # Atomic on POSIX


def load_prefix() -> str:
    """Load prefix from local .bon/prefix file, default to 'bon'.

    Stripped on read: `bon init` writes the file without a trailing newline
    (cli.py), but a hand-written `echo crn > .bon/prefix` adds one, and the
    newline then lands INSIDE every id minted afterwards — `crn\\n-kemize`,
    which `bon show crn-kemize` cannot resolve. Cornichon carried three such
    ids for a week and the failure read as a missing item (bon-nuduta).
    Strip both ends: leading whitespace from a hand-edit is just as wrong,
    and a prefix is never legitimately padded.
    """
    path = _data_dir() / "prefix"
    if path.exists():
        return path.read_text().strip() or "bon"
    return "bon"


ALIASES_FILE = "aliases.jsonl"

# The word bon generates: three consonant-vowel syllables. Only ids ending in
# one are renamed by `bon reprefix`; legacy shapes (mise-02b, trousse-01l.1)
# keep their ids, because a rewrite pattern wide enough to catch them is
# wide enough to catch prose.
WORD = r"[A-Za-z]{6}"
_WORD_RE = re.compile(rf"^{WORD}$")
_ALIAS_TOKEN_TAIL = rf"-{WORD}(?![A-Za-z0-9-])"


def _parse_aliases(path: Path, strict: bool) -> dict[str, dict]:
    """The one reader of .bon/aliases.jsonl: old id -> {"new", "at"}.

    Both ids must be non-empty id-shaped strings and differ. A bad line is
    an error when the caller is about to rewrite the file (strict — writing
    it back would silently drop the line) and a once-per-process warning
    when it is only reading.
    """
    out: dict[str, dict] = {}
    if not path.exists():
        return out
    for n, line in enumerate(path.read_text().splitlines(), 1):
        if not line.strip():
            continue
        try:
            rec = json.loads(line)
            old, new = rec["old"], rec["new"]
            if not (isinstance(old, str) and isinstance(new, str)
                    and ID_SHAPED_ANY.match(old) and ID_SHAPED_ANY.match(new) and old != new):
                raise ValueError(f"old/new must be two different ids, got {old!r} -> {new!r}")
        except (json.JSONDecodeError, KeyError, TypeError, ValueError) as e:
            msg = f"malformed alias on line {n} of {path}: {e}"
            if strict:
                error(msg + " — fix or delete that line; nothing was written.")
            if msg not in _alias_warnings:
                _alias_warnings.add(msg)
                warn(msg + " (skipped)")
            continue
        out[old] = {k: v for k, v in rec.items() if k != "old"}
    return out


_alias_warnings: set[str] = set()
ID_SHAPED_ANY = re.compile(r"^[A-Za-z0-9]+(?:-[A-Za-z0-9.]+)+$")


def load_aliases_at(bon_dir: Path) -> dict[str, str]:
    """Old id -> current id for a re-prefixed board (bon-poboso).

    `bon reprefix` writes one {"old", "new", "at"} line per renamed id.
    find_by_id consults it only on a miss, so on the read side an alias
    never shadows a live id; canonicalise_at drops any key that is a live
    id before rewriting. Uncached: the sync layer re-reads it after a
    rebase that may have delivered it.
    """
    return {o: r["new"] for o, r in _parse_aliases(Path(bon_dir) / ALIASES_FILE, strict=False).items()}


def read_alias_records_at(bon_dir: Path) -> dict[str, dict]:
    """The alias file as old -> {"new", "at"}, for rewriting it whole.
    Strict: a malformed line refuses rather than vanish on the write."""
    return _parse_aliases(Path(bon_dir) / ALIASES_FILE, strict=True)


def write_aliases_at(bon_dir: Path, aliases: dict[str, dict]) -> None:
    """Write the alias file whole, sorted by old id (deterministic diffs).

    `aliases` maps old id -> {"new": ..., "at": ...}. Self-aliases (a board
    renamed back to an earlier prefix) are dropped."""
    path = Path(bon_dir) / ALIASES_FILE
    tmp = path.with_suffix(".tmp")
    with open(tmp, "w") as f:
        for old in sorted(aliases):
            if aliases[old]["new"] == old:
                continue
            f.write(json.dumps({"old": old, **aliases[old]}, ensure_ascii=False) + "\n")
    tmp.rename(path)


def canonicalise(items: list[dict], aliases: dict[str, str],
                 prefix: str | None = None) -> tuple[list[dict], dict[str, str]]:
    """Rewrite every retired id in `items` to its current id, in every string.

    The one transform behind `bon reprefix` and the sync layer: the rename
    applies it to the board, and every later write applies it to base, ours
    and theirs alike — and to the raw file before the union-duplicate scan —
    so a stale clone's edit of an old id merges onto the renamed item instead
    of reading as edit/delete. INVARIANT: any code that compares two versions
    of a board must canonicalise both sides first.

    Gated on membership of the alias map, never on the bare pattern —
    `bon-shaped` in prose is not an id (the cornichon lesson, 2026-08-08).
    The lookbehind excludes `-`, which is what keeps it idempotent when the
    old prefix is the tail of the new one: `mit-kg-zejaja` contains the key
    `kg-zejaja`, and only the `-` before `kg` stops it becoming
    `mit-mit-kg-zejaja` on every save.

    With `prefix` (the board's current one), an item minted under a retired
    prefix after the rename — a stale clone's `bon new` — moves onto the
    current prefix, keeping its word. Those pairs come back as `extra` so the
    caller can record them; the id that verb printed must keep resolving.
    """
    if not aliases:
        return items, {}
    retired = {k.rsplit("-", 1)[0] for k in aliases}
    extra: dict[str, str] = {}
    if prefix:
        taken = {i.get("id") for i in items} | set(aliases.values())
        for item in items:
            iid = item.get("id", "")
            head, _, word = iid.rpartition("-")
            if head in retired and head != prefix and iid not in aliases and _WORD_RE.match(word):
                new = f"{prefix}-{word}"
                if new in taken:
                    warn(f"{iid} carries this board's retired prefix but {new} is taken — "
                         "left as it is; rename it by hand (bon move, or edit the id).")
                    continue
                extra[iid] = new
                taken.add(new)
    amap = {**aliases, **extra} if extra else aliases
    pattern = re.compile(
        r"(?<![A-Za-z0-9-])(?:"
        + "|".join(re.escape(p) for p in sorted(retired, key=len, reverse=True))
        + r")" + _ALIAS_TOKEN_TAIL
    )

    def sub(text: str) -> str:
        return pattern.sub(lambda m: amap.get(m.group(0), m.group(0)), text)

    def tr(value):
        if isinstance(value, str):
            return sub(value)
        if isinstance(value, list):
            return [tr(v) for v in value]
        if isinstance(value, dict):
            return {k: tr(v) for k, v in value.items()}
        return value

    return [tr(i) for i in items], extra


def canonicalise_at(bon_dir: Path, items: list[dict]) -> list[dict]:
    """canonicalise() with the board's aliases and prefix as they stand on
    disk now, recording any stale-minted pairs into the alias file.

    Every alias key is a retired id by construction (only `bon reprefix`
    writes this file), so a live item still carrying one is a stale copy —
    a union-merge twin or an older clone's write — and is renamed with the
    rest. The read side is different: find_by_id consults aliases only on
    a miss, so a lookup can never be redirected away from a live item."""
    bon_dir = Path(bon_dir)
    aliases = load_aliases_at(bon_dir)
    if not aliases:
        return items
    prefix_file = bon_dir / "prefix"
    prefix = prefix_file.read_text().strip() if prefix_file.exists() else None
    out, extra = canonicalise(items, aliases, prefix)
    if extra:
        records = read_alias_records_at(bon_dir)
        for old, new in extra.items():
            records[old] = {"new": new, "at": now_iso()}
            warn(f"{old} was minted under the board's old prefix by a clone that "
                 f"had not pulled the rename; it is now {new} (the old id still resolves).")
        write_aliases_at(bon_dir, records)
    return out


def _canonicalise_archive_at(bon_dir: Path) -> None:
    """Archive lines carrying retired ids (a stale clone's `bon archive`,
    unioned in by the rebase) are rewritten in place. The archive has no
    item-grain merge, so this is its whole convergence step."""
    path = Path(bon_dir) / "archive.jsonl"
    aliases = load_aliases_at(bon_dir)
    if not aliases or not path.exists():
        return
    text = path.read_text()
    try:
        archived = [json.loads(l) for l in text.splitlines() if l.strip()]
    except json.JSONDecodeError:
        # load_archive names the bad line; rewriting would destroy it.
        warn(f"{path} has an unreadable line — its retired ids were left as they are.")
        return
    renamed, _ = canonicalise(archived, aliases)
    seen: dict[str, dict] = {}
    for item in renamed:
        iid = item.get("id", "")
        if iid not in seen or _most_recent_timestamp(item) >= _most_recent_timestamp(seen[iid]):
            seen[iid] = item
    new_text = "".join(json.dumps(i, ensure_ascii=False) + "\n"
                       for i in sorted(seen.values(), key=lambda i: i.get("id", "")))
    if new_text != text:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(new_text)
        tmp.rename(path)


def _drop_archived_twins(bon_dir: Path, items: list[dict]) -> list[dict]:
    """On a re-prefixed board, drop a live item whose id is also archived
    with a stamp at least as new. A rebase of a pre-rename commit over the
    rename unions the clone's whole old board back in; once canonicalised,
    an item archived after the rename reappears as a live twin of its
    archive line. No legitimate path leaves one id in both files (reopen
    and restore move it), so the archived copy is the truth."""
    if not load_aliases_at(bon_dir):
        return items
    path = Path(bon_dir) / "archive.jsonl"
    if not path.exists():
        return items
    archived: dict[str, dict] = {}
    for line in path.read_text().splitlines():
        if line.strip():
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            archived[rec.get("id", "")] = rec
    kept = []
    for item in items:
        twin = archived.get(item.get("id"))
        if twin is not None and _most_recent_timestamp(twin) >= _most_recent_timestamp(item):
            warn(f"{item['id']} is archived; dropped a stale live copy a rebase brought back.")
            continue
        kept.append(item)
    return kept


_alias_notes_shown: set[str] = set()


def _current_aliases() -> dict[str, str]:
    return load_aliases_at(_data_dir())


def find_by_id(items: list[dict], item_id: str, prefix: str | None = None) -> dict | None:
    """Find item by ID. Returns None if not found.

    Searches all items regardless of status (open or done).
    Case-sensitive. Tries exact match first, then prefix + id, then the
    board's aliases (a re-prefixed board's old ids, bon-poboso) — and says
    so on stderr when an alias resolved it, so the reader learns the id moved.

    Args:
        items: All items to search
        item_id: The ID to find (full or suffix)
        prefix: Current prefix for prefix-tolerant matching
    """
    # Exact match first
    for item in items:
        if item["id"] == item_id:
            return item

    # Prefix-tolerant: try prepending prefix
    if prefix and not item_id.startswith(prefix + "-"):
        prefixed = f"{prefix}-{item_id}"
        for item in items:
            if item["id"] == prefixed:
                return item

    # Alias fallback — only ever reached on a miss, so it cannot shadow a live id.
    target = _current_aliases().get(item_id)
    if target:
        for item in items:
            if item["id"] == target:
                if item_id not in _alias_notes_shown:
                    _alias_notes_shown.add(item_id)
                    print(f"note: {item_id} is now {target} (this board was re-prefixed; "
                          "old ids keep resolving)", file=sys.stderr)
                return item

    return None


_creator_cache: str | None = None


def get_creator() -> str:
    """Get creator identifier for new items.

    Returns "{name}" for AI agents (common case), "{name}-tty" for humans typing directly.
    Result is cached after first call (git runs at most once per process).

    Name priority:
    1. BON_USER env var (explicit override)
    2. ARC_USER env var (transition fallback)
    3. git config user.name (most common)
    4. USER env var (fallback)
    5. "unknown" (last resort)
    """
    global _creator_cache
    if _creator_cache is not None:
        return _creator_cache

    # Get the human identity
    name = None

    # Explicit override (BON_USER preferred, ARC_USER fallback)
    if bon_user := os.environ.get("BON_USER"):
        name = bon_user
    elif arc_user := os.environ.get("ARC_USER"):
        # Deprecated old-codename fallback — remove this branch in v0.30+
        warn("ARC_USER is deprecated, use BON_USER (will be removed in v0.30+)")
        name = arc_user

    # Git user name
    if not name:
        try:
            result = subprocess.run(
                ["git", "config", "user.name"],
                capture_output=True, text=True, timeout=2
            )
            if result.returncode == 0 and result.stdout.strip():
                name = result.stdout.strip()
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass

    # System user
    if not name:
        name = os.environ.get("USER", "unknown")

    # Suffix -tty if human is typing directly (rare case)
    if sys.stdin.isatty():
        _creator_cache = f"{name}-tty"
    else:
        _creator_cache = name

    return _creator_cache


def now_iso() -> str:
    """Current time in ISO8601 format."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def stamp(item: dict, verb: str) -> None:
    """Record that `verb` just changed `item` (bon-fobahe).

    Every content change must move updated_at, or the newest-wins readers
    (load dedup, gitsync's union resolver, bon restore) cannot tell the new
    version from the old one. An unknown verb refuses rather than writing a
    stamp `bon doctor` would then flag.
    """
    if verb not in KNOWN_VERBS:
        raise ValueError(f"stamp: unknown updated_by verb {verb!r} — add it to KNOWN_VERBS")
    # A legacy tactical (written before touched_*) keeps its claim's activity
    # only in the item stamp. Move it into the tactical before overwriting,
    # so a sibling reorder or an unblock can't erase it (bon-fobahe essayeur).
    t = item.get("tactical")
    if (isinstance(t, dict) and not t.get("touched_at")
            and item.get("updated_by") in CLAIM_VERBS and item.get("updated_at")):
        t["touched_at"] = item["updated_at"]
        t["touched_by"] = item["updated_by"]
    item["updated_at"] = now_iso()
    item["updated_by"] = verb


# The verbs that act on a tactical claim itself. Only these make an item
# stamp evidence of the claim's activity.
CLAIM_VERBS = frozenset({"worked", "stepped", "released", "reclaimed"})


def stamp_tactical(item: dict, verb: str) -> None:
    """stamp() for a verb acting on the item's tactical claim (work, step,
    release, reclaim) — also records the claim's own activity INSIDE the
    tactical object (bon-fobahe essayeur). Item stamps now move when other
    verbs touch the item (a sibling reorder, an unblock), so claim age and the
    Last-worked hint read these instead. Nested, never a top-level column, so
    an older client's write keeps them (the CLAUDE.md tactical-key gotcha)."""
    stamp(item, verb)
    item["tactical"]["touched_at"] = item["updated_at"]
    item["tactical"]["touched_by"] = verb


def tactical_activity(item: dict) -> tuple[str, str | None]:
    """(when, verb) of the last act on this item's claim: the tactical's own
    record, falling back to the item stamp for tacticals written before it —
    but only when that stamp is a claim verb. Anything else (an edit, a
    reorder) says nothing about the claim, so the answer is ("", None):
    unknown. Callers treat unknown age as old and omit unknown verbs."""
    t = item.get("tactical") or {}
    if t.get("touched_at"):
        return t["touched_at"], t.get("touched_by")
    if item.get("updated_by") in CLAIM_VERBS and item.get("updated_at"):
        return item["updated_at"], item["updated_by"]
    return "", None


def check_initialized() -> None:
    """Check if .bon/ is initialized here or in a parent (up to a .git boundary)."""
    data = _data_dir()
    if not data.is_dir():
        error(
            f"Not initialized: no .bon/ found from {data.parent} upward\n"
            "(the search stops at a .git boundary). Run `bon init` here, or cd\n"
            "into a directory whose repo has a board."
        )
    check_not_stale_dolt_clone(data)
    if _looks_like_cloned_board(data):
        items_file = data / "items.jsonl"
        if items_file.is_file():
            # A live items.jsonl with no prefix marker is a JSONL board whose
            # marker was lost — NOT a clone, NOT a Dolt board. The data is right
            # here; restore the marker. Do not reconnect to Dolt: that would flip
            # a live JSONL board and orphan this file (bon-zageme).
            derived = _derive_prefix_from_items(items_file)
            prefix_hint = derived or "<prefix>"
            error(
                f"{data} has a live items.jsonl but no .bon/prefix marker.\n"
                "This is a JSONL board whose prefix marker was lost — the data is\n"
                "right here, not in Dolt. Restore the marker (non-destructive —\n"
                f"completes the marker, touches nothing else) from {data.parent}:\n"
                f"  bon init --prefix {prefix_hint}\n"
                "(prefix derived from the item IDs in items.jsonl). Then commit\n"
                ".bon/prefix in the origin repo so it can't go missing again."
            )
        # Boards live in their repo as .bon/items.jsonl since Dolt retired
        # (2026-10-24, bon-comowa): the advice is to pull, never to reconnect.
        error(
            f"{data} has bon knowledge files (handoffs/understanding) and no\n"
            "items.jsonl or .bon/prefix marker — this looks like a fresh clone that\n"
            "doesn't have the board yet. Boards live in the repo as .bon/items.jsonl,\n"
            f"so first run `git pull` in {data.parent}. If the origin has no\n"
            ".bon/items.jsonl either, its board is gitignored there; to start one here:\n"
            "  bon init --prefix <prefix>\n"
            "(non-destructive — completes the missing markers, touches nothing else)."
        )


# ---------- cross-repo board access (bon move) ----------

def target_board(root: Path) -> dict:
    """Resolve another repo's board without touching this process's caches.

    Returns {"root", "dir", "prefix"}. Raises BonError when the target has no
    initialized board (no .bon/ or no prefix marker), or is a clone that still
    says backend=dolt.
    """
    root = Path(root).expanduser().resolve()
    bon = root / ".bon"
    if not bon.is_dir() or not (bon / "prefix").is_file():
        raise BonError(
            f"Target not initialized: no .bon/ board with a prefix at {root}.\n"
            "Run `bon init` there first."
        )
    if _is_stale_dolt_clone(bon):
        raise BonError(f"Target {root}: {DOLT_RETIRED}")
    prefix = (bon / "prefix").read_text().strip()
    return {"root": root, "dir": bon, "prefix": prefix}


def load_items_at(board: dict) -> list[dict]:
    """Load items from another repo's board."""
    return _load_items_jsonl(board["dir"] / "items.jsonl")


def save_items_at(board: dict, items: list[dict]) -> None:
    """Save items to another repo's board."""
    _write_board_jsonl(board["dir"] / "items.jsonl", items)


def archive_ids_at(board: dict) -> set[str]:
    """Archived item IDs in another repo's board, for unique-ID generation."""
    ids: set[str] = set()
    path = board["dir"] / "archive.jsonl"
    if path.exists():
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                ids.add(json.loads(line)["id"])
            except (json.JSONDecodeError, KeyError, TypeError):
                continue
    return ids


def apply_reorder(items: list[dict], edited: dict, old_order: int, new_order: int):
    """Shift siblings to accommodate order change.

    Moving from 5 to 2: items at 2, 3, 4 shift to 3, 4, 5.
    Moving from 2 to 5: items at 3, 4, 5 shift to 2, 3, 4.
    """
    if old_order == new_order:
        return

    siblings = [i for i in get_siblings(items, edited["type"], edited.get("parent"))
                if i["id"] != edited["id"]]

    # Each shifted sibling is stamped: an order change is a content change
    # (bon-fobahe). The mover is the caller's to stamp.
    if new_order < old_order:
        # Moving up: shift items in [new, old) down by 1
        for s in siblings:
            if new_order <= s.get("order", 0) < old_order:
                s["order"] += 1
                stamp(s, "reordered")
    else:
        # Moving down: shift items in (old, new] up by 1
        for s in siblings:
            if old_order < s.get("order", 0) <= new_order:
                s["order"] -= 1
                stamp(s, "reordered")


def apply_reparent(items: list[dict], edited: dict, old_parent: str | None, new_parent: str | None):
    """Handle parent change: close gap in old parent, append to new parent.

    When an action moves from one outcome to another:
    1. Close the gap left behind (shift old siblings up)
    2. Append at end of new parent's children
    """
    if old_parent == new_parent:
        return

    old_order = edited.get("order", 1)

    # Close gap in old parent's children
    old_siblings = [i for i in items
                    if i["type"] == "action"
                    and i.get("parent") == old_parent
                    and i["id"] != edited["id"]]
    for s in old_siblings:
        if s.get("order", 0) > old_order:
            s["order"] -= 1
            stamp(s, "reordered")

    # Append to end of new parent's children
    new_siblings = [i for i in items
                    if i["type"] == "action"
                    and i.get("parent") == new_parent
                    and i["id"] != edited["id"]]
    if new_siblings:
        max_order = max(s.get("order", 0) for s in new_siblings)
        edited["order"] = max_order + 1
    else:
        edited["order"] = 1
    # The moved item is stamped here too: cmd_edit and cmd_convert restamp
    # their own subject afterwards, but convert's orphaned children have no
    # other stamp (bon-fobahe).
    stamp(edited, "reparented")


def get_session_identity() -> str:
    """Return the session identity for tactical steps.

    Identity is the .bon root (the directory holding .bon), not the bare
    CWD: walk-up discovery means every subdirectory of a project shares
    the board, so they must also share the one-active-tactical claim —
    otherwise two subdirs of one repo could claim two tacticals on the
    same board. Pre-init (no .bon found) this degrades to CWD, matching
    the old behavior.
    The identity is the realpath of the .bon root.
    """
    return os.path.realpath(_data_dir().parent)


def _tactical_is_active(item: dict) -> bool:
    """Check if an item has active (incomplete) tactical steps.

    A RELEASED tactical is not active: its progress is intact but nobody is
    holding the claim, so it must not block another action from being worked,
    must not be injected into a session's prompt, and must not read as
    orphaned. Gating here covers every caller at once — this is the single
    definition of "someone is working on this" (bon-kewimu).

    `released` lives INSIDE the tactical object rather than beside it as an
    item column. Same reasoning as the `someday` field, one level deeper: an
    older client rewriting the row round-trips `tactical` as one opaque JSON
    value, so a nested key travels with the claim it describes. (The original
    reason — Dolt's fixed _ITEM_COLUMNS list stripping a new top-level column —
    retired with Dolt on 2026-10-24.)
    """
    if item.get("status") != "open":
        return False
    tactical = item.get("tactical")
    if not tactical or tactical.get("released"):
        return False
    return tactical.get("current", 0) < len(tactical.get("steps", []))


def _matches_session(item_session: str | None, session: str | None) -> bool:
    """Check if an item's tactical session matches the requested session.

    - session=None: match only unscoped tacticals (no session field) — backward compat
    - session="/path": match tactical.session == path OR unscoped (legacy claimable)
    """
    if session is None:
        return item_session is None
    return item_session == session or item_session is None


def find_active_tactical(items: list[dict], session: str | None = None) -> dict | None:
    """Find the item with active tactical steps for a given session, or None."""
    for item in items:
        if not _tactical_is_active(item):
            continue
        item_session = item.get("tactical", {}).get("session")
        if _matches_session(item_session, session):
            return item
    return None


def find_any_active_tactical(items: list[dict]) -> list[dict]:
    """Find ALL items with active tactical steps, regardless of session.

    Used for cross-session conflict detection.
    """
    return [item for item in items if _tactical_is_active(item)]


def find_no_complete_tactical(items: list[dict], session: str | None = None) -> dict | None:
    """Find an open action where all tactical steps are done (--no-complete state)."""
    for item in items:
        if item.get("status") != "open" or not item.get("tactical"):
            continue
        tactical = item["tactical"]
        if tactical.get("released"):
            continue
        steps = tactical.get("steps", [])
        if not steps or tactical.get("current", 0) < len(steps):
            continue
        if _matches_session(tactical.get("session"), session):
            return item
    return None


def find_released_tactical(items: list[dict], session: str | None = None) -> dict | None:
    """Find a tactical this session released — progress intact, claim handed back.

    `--status` reports it rather than saying "no active tactical steps": a
    released tactical is deliberately parked work, and answering "nothing
    here" would make it invisible exactly when someone is asking what they
    were doing.
    """
    for item in items:
        if item.get("status") != "open":
            continue
        tactical = item.get("tactical")
        if not tactical or not tactical.get("released"):
            continue
        if _matches_session(tactical.get("session"), session):
            return item
    return None


def find_orphaned_tactical(items: list[dict], session: str) -> dict | None:
    """Find an item with active tactical steps whose session path no longer exists.

    Returns the first orphaned item found, or None. Only checks items
    whose session differs from the given session (current CWD).
    """
    for item in items:
        if not _tactical_is_active(item):
            continue
        item_session = item.get("tactical", {}).get("session")
        if item_session and item_session != session and not os.path.isdir(item_session):
            return item
    return None


def load_archive() -> list[dict]:
    """Load archived items from archive.jsonl."""
    path = _data_dir() / "archive.jsonl"
    if not path.exists():
        return []

    items = []
    for line_num, line in enumerate(path.read_text().splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        try:
            item = json.loads(line)
            items.append(item)
        except json.JSONDecodeError as e:
            print(f"Warning: Skipping malformed archive item on line {line_num}: {e}", file=sys.stderr)

    return items


def append_archive(items: list[dict]) -> None:
    """Append items to archive.jsonl atomically.

    Deduplicates by ID (keeping most recent via _most_recent_timestamp),
    same as save_items. Writes atomically with tmp+rename.
    """
    _refuse_if_half_pulled(_data_dir())
    with _board_lock(_data_dir()):
        _append_archive_jsonl(items)


def _append_archive_jsonl(items: list[dict]) -> None:
    existing = load_archive()

    seen: dict[str, dict] = {}
    for item in existing + items:
        item_id = item.get("id", "")
        if item_id in seen:
            if _most_recent_timestamp(item) >= _most_recent_timestamp(seen[item_id]):
                seen[item_id] = item
        else:
            seen[item_id] = item

    path = _data_dir() / "archive.jsonl"
    tmp = path.with_suffix(".tmp")
    with open(tmp, "w") as f:
        for item in sorted(seen.values(), key=lambda i: i.get("id", "")):
            f.write(json.dumps(item, ensure_ascii=False) + "\n")

    tmp.rename(path)  # Atomic on POSIX


def remove_from_archive(item_id: str, prefix: str | None = None) -> dict | None:
    """Remove an item from archive.jsonl. Returns the item, or None if not found.

    Rewrites archive atomically (same pattern as save_items).
    """
    # Before the lock: a reopen that took the item out of a stray archive and
    # was then refused at save_items would lose it from both files.
    _refuse_if_half_pulled(_data_dir())
    with _board_lock(_data_dir()):
        return _remove_from_archive_jsonl(item_id, prefix)


def _remove_from_archive_jsonl(item_id: str, prefix: str | None) -> dict | None:
    archived = load_archive()
    item = find_by_id(archived, item_id, prefix)
    if not item:
        return None

    remaining = [i for i in archived if i["id"] != item["id"]]
    path = _data_dir() / "archive.jsonl"
    tmp = path.with_suffix(".tmp")
    with open(tmp, "w") as f:
        for i in remaining:
            f.write(json.dumps(i, ensure_ascii=False) + "\n")
    tmp.rename(path)

    return item


def validate_tactical(tactical: dict) -> None:
    """Validate tactical structure. Raises ValidationError if invalid."""
    if not isinstance(tactical.get("steps"), list):
        raise ValidationError("tactical.steps must be a list")
    if not tactical["steps"]:
        raise ValidationError("tactical.steps cannot be empty")
    if not all(isinstance(s, str) for s in tactical["steps"]):
        raise ValidationError("tactical.steps must contain strings")
    current = tactical.get("current", 0)
    if not isinstance(current, int) or current < 0:
        raise ValidationError("tactical.current must be non-negative integer")
    # session is optional; when present must be a non-empty string
    session = tactical.get("session")
    if session is not None and (not isinstance(session, str) or not session):
        raise ValidationError("tactical.session must be a non-empty string")
    # touched_at/touched_by are optional (bon-fobahe); readers parse
    # touched_at as an ISO timestamp, so a non-string must not load.
    for key in ("touched_at", "touched_by"):
        val = tactical.get(key)
        if val is not None and not isinstance(val, str):
            raise ValidationError(f"tactical.{key} must be a string")
    # skipped is optional; when present must be dict with string keys and string values
    skipped = tactical.get("skipped")
    if skipped is not None:
        if not isinstance(skipped, dict):
            raise ValidationError("tactical.skipped must be a dict")
        for key, value in skipped.items():
            if not isinstance(key, str) or not isinstance(value, str):
                raise ValidationError("tactical.skipped keys and values must be strings")
