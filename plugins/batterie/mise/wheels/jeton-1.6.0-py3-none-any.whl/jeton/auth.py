"""
Google OAuth with automatic environment detection.

Modes:
1. Auto (default on desktop): localhost callback server + auto-opens browser
2. Headless (auto-detected): generates auth URL, saves PKCE state, raises HeadlessError
3. Code exchange: pass code= to complete the flow started by either mode
"""

from __future__ import annotations

import base64
import errno
import hashlib
import json
import logging
import os
import socket
import sys
import tempfile
import time
import webbrowser
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from google.auth.exceptions import RefreshError
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow

_log = logging.getLogger(__name__)


class HeadlessError(Exception):
    """Raised when authenticate() detects a headless environment.

    Contains the auth URL so the consumer can display it and instruct
    the user to re-run with --code URL.
    """

    def __init__(self, url: str):
        self.url = url
        super().__init__(
            f"No browser available. Open this URL, then re-run with --code:\n{url}"
        )


def _can_open_browser() -> bool:
    """Check if a graphical environment is available for OAuth callback."""
    if sys.platform == "darwin":
        return True
    return bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))


def load_credentials(
    token_path: str | Path,
    credentials_path: str | Path | None = None,
    scopes: list[str] | None = None,
) -> Credentials | None:
    """Load existing credentials from token file.

    Automatically refreshes if the token is expired but has a refresh_token.

    Args:
        token_path: Path to token.json file
        credentials_path: Path to credentials.json (unused, kept for API compat)
        scopes: Expected scopes (unused, kept for API compat)

    Returns:
        Valid Credentials object, or None when re-authenticating is the fix:
        no token file, an unreadable one, no refresh_token, or a refresh
        Google refused (revoked or invalid grant).

    Raises:
        google.auth.exceptions.TransportError: The refresh couldn't reach
            Google. Not None, because re-authenticating wouldn't help.
        google.auth.exceptions.RefreshError: With .retryable True — Google's
            token endpoint answered 5xx or 429 after google-auth's own
            retries. Same reason. Anything else google-auth raises (a captive
            portal's HTML can surface as TypeError) propagates too.

    A refreshed token that can't be saved is still returned, with a warning
    logged; the next process just refreshes again.
    """
    token_path = Path(token_path)
    if not token_path.exists():
        return None

    try:
        token_data = json.loads(token_path.read_text())
    except (json.JSONDecodeError, IOError):
        return None

    creds = Credentials(
        token=token_data.get("token"),
        refresh_token=token_data.get("refresh_token"),
        token_uri=token_data.get("token_uri", "https://oauth2.googleapis.com/token"),
        client_id=token_data.get("client_id"),
        client_secret=token_data.get("client_secret"),
        scopes=token_data.get("scopes"),
        expiry=_parse_expiry(token_data.get("expiry")),
    )

    # Refresh whenever the token isn't usable. Not `creds.expired`: google-auth
    # reports expired=False when there is no expiry, so a token-less file
    # (ADC's authorized_user shape) would never refresh (jeton-cucice).
    if not creds.valid and creds.refresh_token:
        try:
            creds.refresh(Request())
        except RefreshError as e:
            if e.retryable:
                raise  # the token endpoint is struggling (5xx, 429), not a dead grant
            return None  # Google refused the grant: the caller re-authenticates
        try:
            _save_credentials(creds, token_path)
        except OSError as e:
            _log.warning(
                "Refreshed the OAuth token but could not save it to %s (%s); "
                "using it in memory, so the next process will refresh again.",
                token_path, e,
            )

    return creds if creds.valid else None


def _parse_expiry(value: object) -> datetime | None:
    """A token file's expiry as the naive UTC datetime google-auth compares.

    Absent means none recorded (google-auth then treats the token as never
    expiring). Present but unreadable means unknown, so it reads as long
    past and the token gets refreshed rather than trusted.
    """
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return datetime(1970, 1, 1)
    if parsed.tzinfo is not None:
        parsed = parsed.astimezone(timezone.utc).replace(tzinfo=None)
    return parsed


# ---------------------------------------------------------------------------
# File writes: token.json and .pkce_state.json
#
# Every mise process reads token.json, so it is never written in place: an
# in-place write lets a reader land between truncate and write (a torn file
# reads as "corrupt, re-authenticate"), and a crash there can truncate the only
# refresh token (jeton-jofoha). Both files hold secrets, so they are owner-only.
# ---------------------------------------------------------------------------


def _atomic_write(path: Path, text: str) -> None:
    """Write via a temp file in the same directory, then os.replace.

    A reader sees the old file or the new one, never a torn one. The temp
    file comes from mkstemp, which creates it owner-only, and replace swaps
    that fresh inode in — so the result is 0600 even when the old file was
    0644 (jeton-vedevo), with no chmod needed.
    """
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=path.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


# ---------------------------------------------------------------------------
# PKCE state persistence
#
# .pkce_state.json (next to the token file) holds the code_verifier for every
# auth flow minted but not yet redeemed, KEYED BY THE OAUTH `state` PARAM.
# Keying matters: the old single top-level code_verifier meant two concurrent
# flows (e.g. two sessions re-authing at once) clobbered each other — the
# second mint overwrote the first's verifier, so the first redeem failed with
# "Invalid code verifier" AFTER the consent click was spent (mise-zikesa).
# Now each flow owns its entry; redeem looks up by the state carried in the
# redirect URL.
# ---------------------------------------------------------------------------

_PKCE_FLOW_TTL_S = 3600  # entries older than this are pruned at mint time


def _pkce_challenge(verifier: str) -> str:
    """Compute the S256 code challenge for a verifier (RFC 7636)."""
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


def _pkce_read(path: Path) -> dict:
    """Read the PKCE state file tolerantly. Returns {} on missing/corrupt."""
    try:
        data = json.loads(path.read_text())
        return data if isinstance(data, dict) else {}
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


@contextmanager
def _pkce_lock(path: Path):
    """Advisory lock for read-modify-write on the PKCE state file.

    Sidecar .lock file + flock (POSIX). Without fcntl (Windows) it degrades
    to a no-op: the atomic replace still prevents torn files, and keyed
    entries make the worst case a clear refusal at redeem, never a silent
    clobber.
    """
    try:
        import fcntl
    except ImportError:
        yield
        return
    lock_path = path.with_name(path.name + ".lock")
    with open(lock_path, "w") as fh:
        fcntl.flock(fh, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(fh, fcntl.LOCK_UN)


def _pkce_persist(path: Path, state: str, verifier: str) -> None:
    """Add this flow's verifier under its state key — merge, never clobber.

    Prunes entries older than _PKCE_FLOW_TTL_S. A pre-upgrade top-level
    code_verifier is preserved so an in-flight legacy flow can still redeem
    after jeton upgrades mid-dance.
    """
    with _pkce_lock(path):
        data = _pkce_read(path)
        flows = data.get("flows")
        if not isinstance(flows, dict):
            flows = {}
        now = time.time()
        flows = {
            k: v
            for k, v in flows.items()
            if isinstance(v, dict)
            and now - v.get("created_at", 0) < _PKCE_FLOW_TTL_S
        }
        flows[state] = {"code_verifier": verifier, "created_at": now}
        payload: dict = {"flows": flows}
        if isinstance(data.get("code_verifier"), str):
            payload["code_verifier"] = data["code_verifier"]
        _atomic_write(path, json.dumps(payload))


def _pkce_verify_minted(path: Path, state: str, auth_url: str) -> None:
    """Mint-time self-check: the URL being handed out must match the verifier
    that actually landed on disk (re-read, not the in-memory copy).

    Catches silent write failures and same-instant clobbers. A doomed URL
    burns a human consent click, so abort loudly instead (mise-zikesa).
    """
    params = parse_qs(urlparse(auth_url).query)
    challenge = params.get("code_challenge", [None])[0]
    if challenge is None:
        return  # URL carries no PKCE — nothing to verify
    method = params.get("code_challenge_method", ["S256"])[0]
    entry = _pkce_read(path).get("flows", {}).get(state) or {}
    persisted = entry.get("code_verifier")
    expected = None
    if persisted:
        expected = _pkce_challenge(persisted) if method == "S256" else persisted
    if expected != challenge:
        raise RuntimeError(
            "PKCE self-check failed: the auth URL's code_challenge does not "
            "match the verifier persisted for its state. Handing out this URL "
            "would burn a consent click — the redeem could only fail. Likely "
            "causes: the state file write failed, or another process rewrote "
            "it in the same instant. Re-run authentication."
        )


def _pkce_lookup(path: Path, state: str | None) -> tuple[str, str | None]:
    """Find the verifier for a redeem. Returns (verifier, flow_key).

    flow_key is the state the entry lives under, or None for the legacy
    top-level verifier. With a state (full redirect URL pasted): exact keyed
    lookup, legacy fallback. Without one (bare code): only safe when a single
    flow is in flight — with several, refuse rather than guess, because a
    wrong verifier burns the single-use code at Google's token endpoint.

    Raises ValueError (before any Google call, so the code survives for a
    retry) when no verifier can be found.
    """
    data = _pkce_read(path)
    flows = data.get("flows") if isinstance(data.get("flows"), dict) else {}
    legacy = data.get("code_verifier")
    legacy = legacy if isinstance(legacy, str) else None

    if state is not None:
        entry = flows.get(state)
        if isinstance(entry, dict) and entry.get("code_verifier"):
            return entry["code_verifier"], state
        if legacy:
            return legacy, None
        raise ValueError(
            "No PKCE verifier found for this flow's state. Either the auth "
            "URL was minted on a different machine (mint and redeem must "
            "happen where the same token directory lives), or the state "
            "expired/was cleaned up. Re-run authentication to mint a fresh "
            "URL — this authorization code has NOT been spent."
        )

    live = {k: v for k, v in flows.items()
            if isinstance(v, dict) and v.get("code_verifier")}
    if len(live) == 1:
        key, entry = next(iter(live.items()))
        return entry["code_verifier"], key
    if len(live) > 1:
        raise ValueError(
            f"{len(live)} auth flows are in flight and a bare code doesn't "
            "say which one it belongs to. Paste the FULL redirect URL instead "
            "(it carries the state parameter) — this authorization code has "
            "NOT been spent."
        )
    if legacy:
        return legacy, None
    raise ValueError(
        "No PKCE state found on this machine — the auth URL wasn't minted "
        "here, or its state was cleaned up. Mint and redeem must happen on "
        "the same machine (same token directory). Re-run authentication — "
        "this authorization code has NOT been spent."
    )


def _pkce_consume(path: Path, flow_key: str | None) -> None:
    """Remove the redeemed flow's entry, leaving concurrent flows intact.

    flow_key None = the legacy top-level verifier. Deletes the file when
    nothing remains (matching the old unlink behaviour).
    """
    with _pkce_lock(path):
        data = _pkce_read(path)
        flows = data.get("flows") if isinstance(data.get("flows"), dict) else {}
        if flow_key is None:
            data.pop("code_verifier", None)
        else:
            flows.pop(flow_key, None)
        data["flows"] = flows
        if not flows and not data.get("code_verifier"):
            path.unlink(missing_ok=True)
            return
        _atomic_write(path, json.dumps(data))


def get_auth_url(
    credentials_path: str | Path,
    token_path: str | Path,
    scopes: list[str],
    port: int = 3000,
    include_granted_scopes: bool = False,
) -> str:
    """Generate OAuth URL and save PKCE state for later code exchange.

    Use this for remote/SSH flows where no browser is available locally.
    The caller should display the URL, then later call authenticate(code=...)
    to complete the exchange.

    Args:
        credentials_path: Path to credentials.json from GCP Console
        token_path: Where token will eventually be saved (PKCE state goes next to it)
        scopes: List of full scope URLs
        port: Port baked into the redirect URI (default 3000)
        include_granted_scopes: Ask Google to add every scope this client was
            ever granted for the account (incremental auth). Off by default:
            a client shared by several tools is one grant, so with it on each
            tool's token carries the others' scopes too.

    Returns:
        Authorization URL string

    Raises:
        FileNotFoundError: If credentials.json doesn't exist
    """
    credentials_path = Path(credentials_path)
    token_path = Path(token_path)

    if not credentials_path.exists():
        raise FileNotFoundError(
            f"Credentials file not found: {credentials_path}\n"
            "Download OAuth client credentials from GCP Console:\n"
            "https://console.cloud.google.com/apis/credentials"
        )

    os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = "1"

    redirect_uri = f"http://localhost:{port}/oauth/callback"
    pkce_state_path = token_path.parent / ".pkce_state.json"

    flow = Flow.from_client_secrets_file(
        str(credentials_path),
        scopes=scopes,
        redirect_uri=redirect_uri,
    )

    auth_url, state = flow.authorization_url(
        access_type="offline",
        prompt="consent",
        include_granted_scopes="true" if include_granted_scopes else "false",
    )

    # Save PKCE verifier under this flow's state so authenticate(code=...)
    # can use it later — merged, so concurrent flows don't clobber each other.
    if hasattr(flow, "code_verifier") and flow.code_verifier:
        _pkce_persist(pkce_state_path, state, flow.code_verifier)
        _pkce_verify_minted(pkce_state_path, state, auth_url)

    return auth_url


def authenticate(
    credentials_path: str | Path,
    token_path: str | Path,
    scopes: list[str],
    code: str | None = None,
    port: int = 3000,
    post_auth: dict | None = None,
    state: str | None = None,
    auth_url: str | None = None,
    open_browser: bool | None = None,
    include_granted_scopes: bool = False,
) -> Credentials:
    """Run OAuth flow and save resulting token.

    Three modes:
    - Auto (default): mints a URL, opens browser, listens on localhost
    - Code exchange: pass code= with auth code or redirect URL
      (pair with get_auth_url() for remote/SSH workflows)
    - Listen for a pre-minted URL: pass auth_url= from get_auth_url() and
      this listens for its callback and exchanges the code, without minting
      a second URL (which would orphan the one already handed out)

    Args:
        credentials_path: Path to credentials.json from GCP Console
        token_path: Where to save the resulting token
        scopes: List of full scope URLs
        code: Auth code or redirect URL (for code exchange mode)
        port: Port for localhost callback server (default 3000)
        state: OAuth state param for the flow `code` belongs to. Only needed
            when `code` is a bare code (a full redirect URL carries state
            itself) AND several flows may be in flight — it selects the
            right PKCE verifier from the keyed state file.
        auth_url: A URL minted by get_auth_url() with the same token_path.
            Its state is checked against the callback (CSRF), and the port
            comes from its redirect_uri, so `port` is ignored. Headless is
            fine here: an ssh -L tunnel can deliver the callback, so no
            HeadlessError; the browser is simply not opened. On timeout or a
            refused callback the PKCE verifier stays on disk, so the code=
            path still works.
        open_browser: Whether to open the browser before listening. None
            (default) means detect a graphical session. In auto mode a no
            means HeadlessError, carrying the URL to open elsewhere.
        include_granted_scopes: As for get_auth_url(); applies only when this
            call mints the URL.
        post_auth: Optional dict for post-auth info screen. Keys:
            - copy_value: Value to display for copying
            - copy_label: Label for the copy value
            - message: Instructions to show the user
            - button_url: URL the button opens
            - button_label: Button text

    Returns:
        Valid Credentials object

    Raises:
        FileNotFoundError: If credentials.json doesn't exist
        HeadlessError: If auto mode finds no browser (url attribute has the auth URL)
        ValueError: If authentication fails, or auth_url is unusable (no
            state, not a localhost redirect, no verifier here for it)
        OSError: If the callback port is taken — raised before any browser opens
        TimeoutError: If no callback arrives within 5 minutes
    """
    credentials_path = Path(credentials_path)
    token_path = Path(token_path)
    if code is not None and auth_url is not None:
        raise ValueError("Pass code= or auth_url=, not both")
    if auth_url is not None:
        url_state, port = _pre_minted_state_and_port(auth_url)

    if not credentials_path.exists():
        raise FileNotFoundError(
            f"Credentials file not found: {credentials_path}\n"
            "Download OAuth client credentials from GCP Console:\n"
            "https://console.cloud.google.com/apis/credentials"
        )

    # Relax scope matching — Google sometimes grants different scopes
    os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = "1"

    redirect_uri = f"http://localhost:{port}/oauth/callback"
    pkce_state_path = token_path.parent / ".pkce_state.json"

    flow = Flow.from_client_secrets_file(
        str(credentials_path),
        scopes=scopes,
        redirect_uri=redirect_uri,
    )

    pkce_used = False
    pkce_key: str | None = None

    if code:
        # Code exchange — look up the verifier for THIS flow (keyed by state
        # from the redirect URL, or the explicit state= arg for bare codes).
        auth_code, url_state = _parse_code_and_state(code)
        flow_state = url_state or state
        verifier, pkce_key = _pkce_lookup(pkce_state_path, flow_state)
        flow.code_verifier = verifier
        pkce_used = True

        print("OAuth Authentication")
        print("=" * 50)
        print()
    elif auth_url is not None:
        # Everything that could doom this URL is checked BEFORE listening, so
        # it fails before anyone clicks: the OAuth client it was minted for,
        # and a verifier here that matches its challenge. The lookup alone is
        # not enough: its legacy fallback returns a pre-1.4 verifier for any
        # state it can't find.
        _check_pre_minted_client(auth_url, flow.client_config["client_id"])
        verifier, pkce_key = _pkce_lookup(pkce_state_path, url_state)
        _check_verifier_matches(auth_url, verifier)
        flow.code_verifier = verifier
        pkce_used = True

        print("OAuth Authentication")
        print("=" * 50)
        print()

        auth_code = _listen_for_code(
            auth_url,
            port,
            expected_state=url_state,
            open_browser=_can_open_browser() if open_browser is None else open_browser,
            post_auth=post_auth,
        )
    else:
        # Generate URL and PKCE state
        minted_url, mint_state = flow.authorization_url(
            access_type="offline",
            prompt="consent",
            include_granted_scopes="true" if include_granted_scopes else "false",
        )

        # Save PKCE verifier so --code can work in a separate invocation —
        # keyed by state, merged so concurrent flows don't clobber each other.
        if hasattr(flow, "code_verifier") and flow.code_verifier:
            _pkce_persist(pkce_state_path, mint_state, flow.code_verifier)
            _pkce_verify_minted(pkce_state_path, mint_state, minted_url)
            pkce_used = True
            pkce_key = mint_state

        # Headless detection — raise before trying to open browser/bind port
        if not (_can_open_browser() if open_browser is None else open_browser):
            raise HeadlessError(minted_url)

        print("OAuth Authentication")
        print("=" * 50)
        print()

        auth_code = _listen_for_code(
            minted_url, port, expected_state=mint_state, open_browser=True,
            post_auth=post_auth,
        )

    # Exchange code for tokens (with scope mismatch handling)
    creds = _exchange_code(flow, auth_code)

    # Clean up THIS flow's PKCE entry — concurrent flows keep theirs
    if pkce_used:
        _pkce_consume(pkce_state_path, pkce_key)

    # Save
    _save_credentials(creds, token_path)

    print(f"Token saved to {token_path}")
    print(f"Scopes: {', '.join(creds.scopes or [])}")
    print()
    print("Authentication successful!")

    return creds


# ---------------------------------------------------------------------------
# Callback HTML — minimal, functional
# ---------------------------------------------------------------------------

_SUCCESS_HTML = """<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>OK</title></head><body style="font-family:system-ui;text-align:center;padding:60px">
<h1 style="color:#2e7d32">&#10003; Authorization Successful</h1>
<p>You can close this tab.</p></body></html>"""

_ERROR_HTML = """<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>Error</title></head><body style="font-family:system-ui;text-align:center;padding:60px">
<h1 style="color:#c62828">&#10007; Authorization Failed</h1>
<p><code>{error}</code></p></body></html>"""

_POST_AUTH_HTML = """<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>OK</title></head><body style="font-family:system-ui;text-align:center;padding:60px">
<h1 style="color:#2e7d32">&#10003; Authorization Successful</h1>
<p style="margin:20px 0"><strong>{copy_label}:</strong>
<code style="background:#f5f5f5;padding:4px 8px;font-size:18px;user-select:all">{copy_value}</code></p>
<p>{message}</p>
<p style="margin-top:20px"><a href="{button_url}" target="_blank">{button_label}</a></p>
</body></html>"""


# ---------------------------------------------------------------------------
# Callback server
# ---------------------------------------------------------------------------

class _OAuthCallbackHandler(BaseHTTPRequestHandler):
    """HTTP handler for OAuth callback."""

    def log_message(self, format, *args):
        pass

    def do_GET(self):
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)

        if parsed.path != "/oauth/callback":
            self.send_response(404)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"Not Found")
            return

        # Validate state before anything else (CSRF). A callback carrying some
        # other flow's state — a stale tab, a forged link — is refused, and the
        # listener keeps waiting for its own: ending the flow on it would let a
        # stale tab kill a live sign-in.
        expected_state = getattr(self.server, "expected_state", None)
        if expected_state is not None:
            callback_state = params.get("state", [None])[0]
            if callback_state != expected_state:
                self.send_response(400)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(
                    _ERROR_HTML.format(
                        error="State mismatch — this tab belongs to a different "
                        "or older sign-in, so it was ignored. Use the newest link."
                    ).encode()
                )
                return

        error = params.get("error", [None])[0]
        if error:
            self.send_response(400)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(_ERROR_HTML.format(error=error).encode())
            self.server.auth_code = None
            self.server.auth_error = error
            return

        code = params.get("code", [None])[0]
        if not code:
            self.send_response(400)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(_ERROR_HTML.format(error="No authorization code received").encode())
            self.server.auth_code = None
            return

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()

        post_auth = getattr(self.server, "post_auth", None)
        if post_auth:
            import html
            self.wfile.write(_POST_AUTH_HTML.format(
                copy_value=html.escape(str(post_auth.get("copy_value", ""))),
                copy_label=html.escape(str(post_auth.get("copy_label", "Value"))),
                message=html.escape(str(post_auth.get("message", ""))),
                button_url=html.escape(str(post_auth.get("button_url", "#"))),
                button_label=html.escape(str(post_auth.get("button_label", "Continue"))),
            ).encode())
        else:
            self.wfile.write(_SUCCESS_HTML.encode())

        self.server.auth_code = code


# ---------------------------------------------------------------------------
# Auth flows
# ---------------------------------------------------------------------------

_CALLBACK_TIMEOUT_S = 300  # how long a listener waits for Google's redirect


def _pre_minted_state_and_port(auth_url: str) -> tuple[str, int]:
    """The state and callback port a pre-minted URL commits to.

    The callback lands on the URL's redirect_uri, and the code exchange must
    repeat that redirect_uri exactly, so the port comes from the URL rather
    than from the caller. A URL without a state can't be CSRF-checked, so it
    is refused rather than trusted.
    """
    params = parse_qs(urlparse(auth_url).query)
    state = params.get("state", [None])[0]
    if not state:
        raise ValueError(
            "auth_url has no state parameter, so its callback can't be checked "
            "against it. Pass a URL minted by get_auth_url()."
        )
    redirect = urlparse(params.get("redirect_uri", [""])[0])
    try:
        port = redirect.port
    except ValueError:
        port = None
    if (redirect.scheme != "http" or redirect.hostname != "localhost" or not port
            or redirect.path != "/oauth/callback"):
        raise ValueError(
            "auth_url's redirect_uri is not http://localhost:<port>/oauth/callback, "
            "so this listener can't receive its callback."
        )
    return state, port


def _check_pre_minted_client(auth_url: str, client_id: str) -> None:
    """The URL must have been minted for the OAuth client we'd exchange with.

    Google would accept the consent and then refuse the exchange, so a URL
    from another client (another Workspace's credentials.json) burns a click.
    """
    url_client = parse_qs(urlparse(auth_url).query).get("client_id", [None])[0]
    if url_client != client_id:
        raise ValueError(
            f"auth_url was minted for OAuth client {url_client!r}, but the "
            f"credentials file here is {client_id!r}. Mint and finish with the "
            "same credentials file."
        )


def _check_verifier_matches(auth_url: str, verifier: str) -> None:
    """The verifier we'd send must answer the URL's code_challenge."""
    params = parse_qs(urlparse(auth_url).query)
    challenge = params.get("code_challenge", [None])[0]
    if challenge is None:
        return  # URL carries no PKCE challenge: nothing to match
    method = params.get("code_challenge_method", ["S256"])[0]
    answer = _pkce_challenge(verifier) if method == "S256" else verifier
    if answer != challenge:
        raise ValueError(
            "The PKCE verifier saved here doesn't match this auth_url, so the "
            "exchange could only fail. It was probably minted against another "
            "token directory. Mint a fresh URL with get_auth_url() here."
        )


def _refuse_if_ipv6_loopback_taken(port: int) -> None:
    """Raise EADDRINUSE if something already serves [::1]:port.

    The listener binds 127.0.0.1, but a browser resolving localhost may try
    ::1 first, and a dev server there (Node 17+, Vite) would catch the
    callback instead: the flow fails after the click. A box with no IPv6
    loopback has nothing to collide with.
    """
    try:
        probe = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
    except OSError:
        return  # no IPv6 on this box
    try:
        probe.bind(("::1", port))
    except OSError as e:
        if e.errno == errno.EADDRINUSE:
            raise
    finally:
        probe.close()


def _listen_for_code(
    auth_url: str,
    port: int,
    *,
    expected_state: str | None,
    open_browser: bool,
    post_auth: dict | None = None,
) -> str:
    """Catch Google's redirect on localhost and return the authorization code.

    Binds BEFORE opening the browser, so a taken port fails before a consent
    click is spent. Threaded, because a single-threaded server blocks on the
    spare connection Chrome opens and never uses, and the real callback then
    waits behind it forever (both found live in mise, jeton-jedaza).
    """
    try:
        _refuse_if_ipv6_loopback_taken(port)
        server = ThreadingHTTPServer(("localhost", port), _OAuthCallbackHandler)
    except OSError as e:
        held = e.errno == errno.EADDRINUSE
        raise OSError(
            e.errno,
            f"Cannot listen on localhost:{port} for the OAuth callback"
            + (" — another process holds the port" if held else "")
            + f" ({e.strerror}). No browser was opened. "
            + ("Free the port, or finish" if held else "Finish")
            + " with get_auth_url() + authenticate(code=...).",
        ) from e
    server.daemon_threads = True  # an idle speculative connection can't hold up exit
    server.timeout = 1.0  # handle_request wakes to check for a result or the deadline
    server.auth_code = None
    server.auth_error = None
    server.post_auth = post_auth
    server.expected_state = expected_state

    try:
        print("Authorization URL:")
        print(auth_url)
        print()
        if open_browser:
            try:
                webbrowser.open(auth_url)
                print("Browser opened automatically")
            except Exception:
                print("Could not auto-open browser — please copy URL manually")
        else:
            print("Not opening a browser here. Open the URL above in a browser")
            print("signed into the right account; the callback must reach")
            print(f"localhost:{port} on THIS machine (ssh -L {port}:localhost:{port} <host>")
            print("before clicking, if the browser is elsewhere).")
        print()
        print(f"Listening on http://localhost:{port}/oauth/callback "
              f"(up to {_CALLBACK_TIMEOUT_S // 60} minutes)")

        deadline = time.monotonic() + _CALLBACK_TIMEOUT_S
        while server.auth_code is None and server.auth_error is None:
            if time.monotonic() > deadline:
                raise TimeoutError(
                    f"No OAuth callback within {_CALLBACK_TIMEOUT_S // 60} minutes. "
                    "The PKCE verifier is still saved, so the redirect URL can "
                    "still be finished with authenticate(code=...)."
                )
            server.handle_request()
    finally:
        server.server_close()

    if server.auth_error:
        raise ValueError(f"OAuth error: {server.auth_error}")

    print("Authorization code received")
    return server.auth_code


def _parse_code_from_input(input_str: str) -> str:
    """Extract authorization code from URL or raw code."""
    code, _ = _parse_code_and_state(input_str)
    return code


def _parse_code_and_state(input_str: str) -> tuple[str, str | None]:
    """Extract authorization code and state from URL or raw code.

    Returns:
        (code, state) — state is None when input is a raw code (not a URL).
    """
    input_str = input_str.strip()

    try:
        parsed = urlparse(input_str)
        params = parse_qs(parsed.query)
        code = params.get("code", [None])[0]
        if code:
            state = params.get("state", [None])[0]
            return code, state
    except Exception:
        pass

    return input_str, None


def _exchange_code(flow: Flow, code: str) -> Credentials:
    """Exchange authorization code for tokens.

    Handles the "Scope has changed" error from incremental authorization.
    """
    print()
    print("Exchanging authorization code for tokens...")

    try:
        flow.fetch_token(code=code)
        return flow.credentials
    except ValueError as e:
        if "Scope has changed" not in str(e):
            raise

        # Scope mismatch — extract tokens manually from session
        print("Google granted additional scopes (incremental authorization)")
        print("Proceeding with granted permissions...")
        print()

        token_data = flow.oauth2session.token

        expiry = None
        if "expires_in" in token_data:
            expiry = datetime.utcnow() + timedelta(seconds=token_data["expires_in"])
        elif "expires_at" in token_data:
            expiry = datetime.utcfromtimestamp(token_data["expires_at"])

        scope_data = token_data.get("scope", "")
        if isinstance(scope_data, str):
            scopes = scope_data.split()
        else:
            scopes = list(scope_data) if scope_data else []

        return Credentials(
            token=token_data.get("access_token"),
            refresh_token=token_data.get("refresh_token"),
            token_uri="https://oauth2.googleapis.com/token",
            client_id=flow.client_config["client_id"],
            client_secret=flow.client_config["client_secret"],
            scopes=scopes,
            expiry=expiry,
        )


def _save_credentials(creds: Credentials, token_path: Path):
    """Save credentials to JSON file, preserving any non-canonical top-level keys.

    Downstream consumers may stash extra metadata (e.g. an ``_identity`` cue, an
    audit label) alongside the OAuth fields. Merging on write keeps that data
    alive across the hourly refresh cycle.
    """
    token_data: dict = {}
    if token_path.exists():
        try:
            existing = json.loads(token_path.read_text())
            if isinstance(existing, dict):
                token_data = existing
        except (json.JSONDecodeError, OSError):
            pass

    token_data.update({
        "token": creds.token,
        "refresh_token": creds.refresh_token,
        "token_uri": creds.token_uri,
        "client_id": creds.client_id,
        "client_secret": creds.client_secret,
        "scopes": list(creds.scopes) if creds.scopes else [],
        "expiry": creds.expiry.isoformat() if creds.expiry else None,
    })
    _atomic_write(token_path, json.dumps(token_data, indent=2))
