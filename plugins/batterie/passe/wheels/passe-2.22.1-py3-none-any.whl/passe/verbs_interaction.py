"""Interaction verbs — click, fill, type, select, press, hover, tap, swipe, scroll."""

import asyncio
import json
import sys

from passe.client import CDPClient
from passe.refcache import REF_PATTERN, load_refs, tab_id_of


async def _resolve_ref(client: CDPClient, ref: str) -> str:
    """Resolve an eN ref (from ax-tree --flat-refs) to a Runtime objectId.

    Raises RuntimeError with re-snap guidance when the ref is unknown or
    the cached backendDOMNodeId no longer resolves (page navigated).
    """
    refs = load_refs(tab_id_of(client))
    if not refs or ref not in refs:
        raise RuntimeError(
            f'ref {ref!r} not found — run "ax-tree --flat-refs" first '
            f'(refs are cleared on navigation)')
    backend_id = refs[ref]
    try:
        # getDocument first: resolveNode needs the DOM agent to know the tree
        await client.send('DOM.getDocument', {'depth': 0})
        resolved = await client.send('DOM.resolveNode',
                                     {'backendNodeId': backend_id})
        return resolved['result']['object']['objectId']
    except Exception:
        raise RuntimeError(
            f'ref {ref!r} is stale (page changed since the snapshot) — '
            f're-run "ax-tree --flat-refs"')


async def _call_on_ref(client: CDPClient, ref: str, fn: str, verb: str) -> dict:
    """Run a functionDeclaration with `this` bound to the ref's element."""
    object_id = await _resolve_ref(client, ref)
    result = await client.send('Runtime.callFunctionOn', {
        'objectId': object_id,
        'functionDeclaration': fn,
        'returnByValue': True,
    })
    if 'exceptionDetails' in result.get('result', {}):
        desc = result['result']['exceptionDetails'].get(
            'exception', {}).get('description', '')
        raise RuntimeError(f'{verb} {ref} failed: {desc}')
    return result


# JS that finds a click target and returns it as a JSON centre point after
# scrolling it into view. Used by the trusted path, which clicks a point.
_CENTRE_FN = (
    'function() { this.scrollIntoView({block: "center"});'
    ' const r = this.getBoundingClientRect();'
    ' return JSON.stringify({x: r.x + r.width/2, y: r.y + r.height/2,'
    ' tag: this.tagName.toLowerCase()}); }')

# Finds the element by visible text (exact, then partial), as click-text does.
# MODE 'click' clicks it in JS; MODE 'centre' marks it and returns its centre.
_TEXT_FIND_JS = '''(() => {{
    const label = {label};
    const mode = {mode};
    const act = (el, how) => {{
        if (mode === 'click') {{ el.click(); return how; }}
        el.scrollIntoView({{block: "center"}});
        const r = el.getBoundingClientRect();
        return JSON.stringify({{x: r.x + r.width/2, y: r.y + r.height/2,
                                tag: el.tagName.toLowerCase()}});
    }};
    for (const exact of [true, false]) {{
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        while (walker.nextNode()) {{
            const node = walker.currentNode;
            const t = node.textContent.trim();
            if (exact ? t === label : t.includes(label)) {{
                const el = node.parentElement;
                if (el && el.offsetParent !== null) {{
                    return act(el, exact ? 'clicked' : 'clicked-partial');
                }}
            }}
        }}
    }}
    throw new Error('No visible element with text: ' + label);
}})()'''


async def _eval_or_raise(client: CDPClient, js: str, what: str):
    result = await client.send('Runtime.evaluate', {
        'expression': js, 'awaitPromise': False, 'returnByValue': True,
    })
    if 'exceptionDetails' in result.get('result', {}):
        desc = result['result']['exceptionDetails'].get('exception', {}).get('description', '')
        raise RuntimeError(f'{what} failed: {desc}')
    return result.get('result', {}).get('result', {}).get('value')


async def _trusted_click_at(client: CDPClient, centre: dict, target: str):
    """Click a point with real input events, so the page sees a user gesture.

    A JS el.click() is untrusted: popups (target=_blank, window.open, most
    "Sign in with ..." buttons), clipboard writes, file pickers and fullscreen
    all ignore it, and passe used to report success anyway. CDP mouse events
    are trusted, but a background tab (passe's default) is not hit-tested
    until it believes it has focus, so focus emulation goes on first. That
    keeps the human's foreground tab where it is, unlike Page.bringToFront.
    Measured on Chrome 158 (atelier, 22 Nov 2026): without focus emulation the
    events were accepted and nothing happened.
    """
    await client.send('Emulation.setFocusEmulationEnabled', {'enabled': True})
    x, y = centre['x'], centre['y']
    hit = await _eval_or_raise(client, f'''(() => {{
        const el = document.elementFromPoint({x}, {y});
        return el ? el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') : null;
    }})()''', 'click --trusted')
    if hit is None:
        raise RuntimeError(
            f'click --trusted {target}: its centre ({x:.0f}, {y:.0f}) is outside '
            'the viewport, so a real click would land on nothing')
    await client.send('Input.dispatchMouseEvent', {'type': 'mouseMoved', 'x': x, 'y': y})
    for kind in ('mousePressed', 'mouseReleased'):
        await client.send('Input.dispatchMouseEvent', {
            'type': kind, 'x': x, 'y': y, 'button': 'left', 'clickCount': 1})
    if not hit.startswith(centre.get('tag', '')):
        # Not fatal: a link's centre often lands on a child span. Said so the
        # caller can tell an overlay that ate the click from a real miss.
        print(f'[click] --trusted: point over {target} is topmost <{hit}>, '
              f'target is <{centre.get("tag")}>', file=sys.stderr)


async def do_click(client: CDPClient, selector: str, trusted: bool = False):
    if REF_PATTERN.match(selector):
        if trusted:
            result = await _call_on_ref(client, selector, _CENTRE_FN, 'click')
            await _trusted_click_at(
                client, json.loads(result['result']['result']['value']), selector)
            return
        await _call_on_ref(
            client, selector,
            'function() { this.scrollIntoView({block: "center"}); this.click(); }',
            'click')
        return
    if trusted:
        centre = await _eval_or_raise(client, f'''(() => {{
            const el = document.querySelector({json.dumps(selector)});
            if (!el) throw new Error('No element matches: ' + {json.dumps(selector)});
            return ({_CENTRE_FN}).call(el);
        }})()''', 'click')
        await _trusted_click_at(client, json.loads(centre), selector)
        return
    await _eval_or_raise(client, f'''(() => {{
        const el = document.querySelector({json.dumps(selector)});
        if (!el) throw new Error('No element matches: ' + {json.dumps(selector)});
        el.click();
    }})()''', 'click')


async def do_click_text(client: CDPClient, label: str, trusted: bool = False):
    mode = 'centre' if trusted else 'click'
    js = _TEXT_FIND_JS.format(label=json.dumps(label), mode=json.dumps(mode))
    value = await _eval_or_raise(client, js, 'click-text')
    if trusted:
        await _trusted_click_at(client, json.loads(value), repr(label))


async def do_fill(client: CDPClient, selector: str, value: str):
    js = f'''(() => {{
        const el = document.querySelector({json.dumps(selector)});
        if (!el) throw new Error('No element matches: ' + {json.dumps(selector)});
        el.value = {json.dumps(value)};
        el.dispatchEvent(new Event("input", {{bubbles: true}}));
        el.dispatchEvent(new Event("change", {{bubbles: true}}));
    }})()'''
    result = await client.send('Runtime.evaluate', {
        'expression': js, 'awaitPromise': False
    })
    if 'exceptionDetails' in result.get('result', {}):
        desc = result['result']['exceptionDetails'].get('exception', {}).get('description', '')
        raise RuntimeError(f'fill failed: {desc}')


async def do_type(client: CDPClient, selector: str, text: str):
    from passe.verbs_observation import do_eval

    if REF_PATTERN.match(selector):
        await _call_on_ref(
            client, selector,
            'function() { this.scrollIntoView({block: "center"}); this.focus(); }',
            'type')
        for char in text:
            await client.send('Input.insertText', {'text': char})
        check = await _call_on_ref(
            client, selector, 'function() { return this.value; }', 'type')
        actual = check.get('result', {}).get('result', {}).get('value')
        if actual != text:
            await _call_on_ref(client, selector, f'''function() {{
                this.focus();
                const proto = this.tagName === 'TEXTAREA'
                    ? window.HTMLTextAreaElement.prototype
                    : window.HTMLInputElement.prototype;
                const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
                setter.call(this, {json.dumps(text)});
                this.dispatchEvent(new Event('input', {{ bubbles: true }}));
                this.dispatchEvent(new Event('change', {{ bubbles: true }}));
            }}''', 'type')
            await asyncio.sleep(0.1)
            print('[type] React controlled input detected — used '
                  'nativeInputValueSetter', file=sys.stderr)
        return

    # Focus the element first
    js = f'''(() => {{
        const el = document.querySelector({json.dumps(selector)});
        if (!el) throw new Error('No element matches: ' + {json.dumps(selector)});
        el.focus();
        return true;
    }})()'''
    result = await client.send('Runtime.evaluate', {
        'expression': js, 'awaitPromise': False
    })
    if 'exceptionDetails' in result.get('result', {}):
        desc = result['result']['exceptionDetails'].get('exception', {}).get('description', '')
        raise RuntimeError(f'type focus failed: {desc}')
    # Type each character via CDP Input.insertText (matches Puppeteer).
    # dispatchKeyEvent rawKeyDown/char/keyUp dispatches events but doesn't
    # reliably insert characters. insertText triggers beforeinput + input
    # events which frameworks (React, Vue) pick up correctly.
    for char in text:
        await client.send('Input.insertText', {'text': char})
    # Auto-detect React controlled inputs: if value didn't take, use nativeInputValueSetter
    check_js = f'document.querySelector({json.dumps(selector)}).value'
    actual = await do_eval(client, check_js)
    if actual != text:
        fallback_js = f'''(() => {{
            const el = document.querySelector({json.dumps(selector)});
            el.focus();
            const proto = el.tagName === 'TEXTAREA'
                ? window.HTMLTextAreaElement.prototype
                : window.HTMLInputElement.prototype;
            const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
            setter.call(el, {json.dumps(text)});
            el.dispatchEvent(new Event('input', {{ bubbles: true }}));
            el.dispatchEvent(new Event('change', {{ bubbles: true }}));
        }})()'''
        await client.send('Runtime.evaluate', {
            'expression': fallback_js, 'awaitPromise': False
        })
        # Give React time to reconcile after the synthetic input/change events.
        # Without this, the next verb (e.g. press Enter) fires via CDP before
        # React has updated its internal state from the dispatched events.
        await asyncio.sleep(0.1)
        print(f'[type] React controlled input detected — used nativeInputValueSetter', file=sys.stderr)


async def do_select(client: CDPClient, selector: str, value: str):
    js = f'''(() => {{
        const el = document.querySelector({json.dumps(selector)});
        if (!el) throw new Error('No element matches: ' + {json.dumps(selector)});
        el.value = {json.dumps(value)};
        el.dispatchEvent(new Event("change", {{bubbles: true}}));
    }})()'''
    result = await client.send('Runtime.evaluate', {
        'expression': js, 'awaitPromise': False
    })
    if 'exceptionDetails' in result.get('result', {}):
        desc = result['result']['exceptionDetails'].get('exception', {}).get('description', '')
        raise RuntimeError(f'select failed: {desc}')


async def do_press(client: CDPClient, key: str):
    # Map common key names to CDP key values
    key_map = {
        'enter': ('Enter', '\r', 13),
        'tab': ('Tab', '\t', 9),
        'escape': ('Escape', '', 27),
        'backspace': ('Backspace', '', 8),
        'delete': ('Delete', '', 46),
        'arrowup': ('ArrowUp', '', 38),
        'arrowdown': ('ArrowDown', '', 40),
        'arrowleft': ('ArrowLeft', '', 37),
        'arrowright': ('ArrowRight', '', 39),
        'space': (' ', ' ', 32),
    }
    lower = key.lower()
    if lower in key_map:
        key_name, text, code = key_map[lower]
    else:
        key_name, text, code = key, key, ord(key) if len(key) == 1 else 0

    params = {'type': 'keyDown', 'key': key_name, 'windowsVirtualKeyCode': code}
    if text:
        params['text'] = text
    await client.send('Input.dispatchKeyEvent', params)
    await client.send('Input.dispatchKeyEvent', {
        'type': 'keyUp', 'key': key_name, 'windowsVirtualKeyCode': code
    })


async def do_hover(client: CDPClient, selector: str):
    if REF_PATTERN.match(selector):
        result = await _call_on_ref(client, selector, '''function() {
            this.scrollIntoView({block: "center"});
            const rect = this.getBoundingClientRect();
            return JSON.stringify({x: rect.x + rect.width/2, y: rect.y + rect.height/2});
        }''', 'hover')
        coords = json.loads(result['result']['result']['value'])
        await client.send('Input.dispatchMouseEvent', {
            'type': 'mouseMoved', 'x': coords['x'], 'y': coords['y']
        })
        return
    js = f'''(() => {{
        const el = document.querySelector({json.dumps(selector)});
        if (!el) throw new Error('No element matches: ' + {json.dumps(selector)});
        const rect = el.getBoundingClientRect();
        return JSON.stringify({{x: rect.x + rect.width/2, y: rect.y + rect.height/2}});
    }})()'''
    result = await client.send('Runtime.evaluate', {
        'expression': js, 'awaitPromise': False
    })
    if 'exceptionDetails' in result.get('result', {}):
        desc = result['result']['exceptionDetails'].get('exception', {}).get('description', '')
        raise RuntimeError(f'hover failed: {desc}')
    coords = json.loads(result['result']['result']['value'])
    await client.send('Input.dispatchMouseEvent', {
        'type': 'mouseMoved', 'x': coords['x'], 'y': coords['y']
    })


async def do_tap(client: CDPClient, selector: str):
    """Dispatch real touch events (touchstart + touchend) on element center.

    Uses JS TouchEvent synthesis rather than CDP Input.dispatchTouchEvent
    because the CDP method doesn't respond through flattened sessions
    (browser-level WS + sessionId).  JS synthesis is reliable, portable,
    and fires the same events real touches do.
    """
    js = f'''(() => {{
        const el = document.querySelector({json.dumps(selector)});
        if (!el) throw new Error('No element matches: ' + {json.dumps(selector)});
        const rect = el.getBoundingClientRect();
        const x = rect.x + rect.width / 2;
        const y = rect.y + rect.height / 2;
        const touch = new Touch({{
            identifier: 1, target: el,
            clientX: x, clientY: y, pageX: x, pageY: y
        }});
        el.dispatchEvent(new TouchEvent('touchstart', {{
            touches: [touch], targetTouches: [touch], changedTouches: [touch],
            bubbles: true, cancelable: true
        }}));
        el.dispatchEvent(new TouchEvent('touchend', {{
            touches: [], targetTouches: [], changedTouches: [touch],
            bubbles: true, cancelable: true
        }}));
    }})()'''
    result = await client.send('Runtime.evaluate', {
        'expression': js, 'awaitPromise': False
    })
    if 'exceptionDetails' in result.get('result', {}):
        desc = result['result']['exceptionDetails'].get('exception', {}).get('description', '')
        raise RuntimeError(f'tap failed: {desc}')


async def do_swipe(client: CDPClient, selector: str, direction: str, distance: int = 200) -> dict:
    """Dispatch a touch swipe gesture (touchstart + touchmove sequence + touchend).

    Same JS synthesis approach as do_tap — CDP Input.dispatchTouchEvent
    doesn't work through flattened sessions.

    Returns dict with start/end coordinates for step NDJSON reporting.
    """
    # Direction → (dx, dy) unit vector
    vectors = {'left': (-1, 0), 'right': (1, 0), 'up': (0, -1), 'down': (0, 1)}
    if direction not in vectors:
        raise RuntimeError(f'swipe: unknown direction {direction!r} — use left, right, up, down')
    dx, dy = vectors[direction]
    steps = 8  # intermediate touchmove points for realism
    js = f'''(() => {{
        const el = document.querySelector({json.dumps(selector)});
        if (!el) throw new Error('No element matches: ' + {json.dumps(selector)});
        const rect = el.getBoundingClientRect();
        const cx = rect.x + rect.width / 2;
        const cy = rect.y + rect.height / 2;
        const dx = {dx * distance};
        const dy = {dy * distance};
        const steps = {steps};
        const startX = cx - dx / 2;
        const startY = cy - dy / 2;

        function mkTouch(x, y) {{
            return new Touch({{
                identifier: 1, target: el,
                clientX: x, clientY: y, pageX: x, pageY: y
            }});
        }}

        // touchstart
        const t0 = mkTouch(startX, startY);
        el.dispatchEvent(new TouchEvent('touchstart', {{
            touches: [t0], targetTouches: [t0], changedTouches: [t0],
            bubbles: true, cancelable: true
        }}));

        // touchmove sequence
        for (let i = 1; i <= steps; i++) {{
            const frac = i / steps;
            const t = mkTouch(startX + dx * frac, startY + dy * frac);
            el.dispatchEvent(new TouchEvent('touchmove', {{
                touches: [t], targetTouches: [t], changedTouches: [t],
                bubbles: true, cancelable: true
            }}));
        }}

        // touchend at final position
        const tEnd = mkTouch(startX + dx, startY + dy);
        el.dispatchEvent(new TouchEvent('touchend', {{
            touches: [], targetTouches: [], changedTouches: [tEnd],
            bubbles: true, cancelable: true
        }}));

        return JSON.stringify({{
            startX: Math.round(startX), startY: Math.round(startY),
            endX: Math.round(startX + dx), endY: Math.round(startY + dy)
        }});
    }})()'''
    result = await client.send('Runtime.evaluate', {
        'expression': js, 'awaitPromise': False
    })
    if 'exceptionDetails' in result.get('result', {}):
        desc = result['result']['exceptionDetails'].get('exception', {}).get('description', '')
        raise RuntimeError(f'swipe failed: {desc}')
    return json.loads(result['result']['result']['value'])


async def do_scroll(client: CDPClient, x: int, y: int):
    await client.send('Runtime.evaluate', {
        'expression': f'window.scrollTo({x}, {y})',
        'awaitPromise': False
    })
