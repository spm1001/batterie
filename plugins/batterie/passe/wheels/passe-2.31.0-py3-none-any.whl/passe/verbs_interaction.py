"""Interaction verbs — click, fill, type, select, press, hover, tap, swipe, scroll."""

import asyncio
import json
import sys

from passe.client import CDPClient
from passe.refcache import REF_PATTERN, load_refs, tab_id_of


async def _resolve_ref(client: CDPClient, ref: str) -> str:
    """Resolve an eN ref (from ax-tree --flat-refs) to a Runtime objectId.

    Raises RuntimeError with re-snap guidance when the ref is unknown or
    the cached backendDOMNodeId no longer resolves (page navigated).
    """
    refs = load_refs(tab_id_of(client))
    if not refs or ref not in refs:
        raise RuntimeError(
            f'ref {ref!r} not found — run "ax-tree --flat-refs" first '
            f'(refs are cleared on navigation)')
    backend_id = refs[ref]
    try:
        # getDocument first: resolveNode needs the DOM agent to know the tree
        await client.send('DOM.getDocument', {'depth': 0})
        resolved = await client.send('DOM.resolveNode',
                                     {'backendNodeId': backend_id})
        return resolved['result']['object']['objectId']
    except Exception:
        raise RuntimeError(
            f'ref {ref!r} is stale (page changed since the snapshot) — '
            f're-run "ax-tree --flat-refs"')


async def _call_on_ref(client: CDPClient, ref: str, fn: str, verb: str) -> dict:
    """Run a functionDeclaration with `this` bound to the ref's element."""
    object_id = await _resolve_ref(client, ref)
    result = await client.send('Runtime.callFunctionOn', {
        'objectId': object_id,
        'functionDeclaration': fn,
        'returnByValue': True,
    })
    if 'exceptionDetails' in result.get('result', {}):
        desc = result['result']['exceptionDetails'].get(
            'exception', {}).get('description', '')
        raise RuntimeError(f'{verb} {ref} failed: {desc}')
    return result


# Finds the element by visible text (exact, then partial), as click-text does.
# MODE 'click' clicks it in JS; MODE 'element' returns the element itself.
_TEXT_FIND_JS = """(() => {{
    const label = {label};
    const mode = {mode};
    for (const exact of [true, false]) {{
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        while (walker.nextNode()) {{
            const node = walker.currentNode;
            const t = node.textContent.trim();
            if (exact ? t === label : t.includes(label)) {{
                const el = node.parentElement;
                if (el && el.offsetParent !== null) {{
                    if (mode === 'element') return el;
                    el.click();
                    return exact ? 'clicked' : 'clicked-partial';
                }}
            }}
        }}
    }}
    throw new Error('No visible element with text: ' + label);
}})()"""

# Bound to the target: scroll it into view without animation (a smooth scroll
# would move it after we read its box), refuse a zero-size or detached
# element (its centre is 0,0, which clicks whatever sits top-left), and
# hit-test the centre against the target and its descendants.
_TRUSTED_PREP_FN = """function() {
    const desc = el => el ? el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') : null;
    if (!this.isConnected) return JSON.stringify({err: 'is no longer in the page'});
    this.scrollIntoView({block: 'center', inline: 'center', behavior: 'instant'});
    const r = this.getBoundingClientRect();
    if (r.width === 0 || r.height === 0)
        return JSON.stringify({err: 'has no size on screen (hidden or display:none)'});
    const x = r.x + r.width / 2, y = r.y + r.height / 2;
    const hit = document.elementFromPoint(x, y);
    return JSON.stringify({x: x, y: y, in_view: hit !== null,
        on_target: !!hit && (hit === this || this.contains(hit)),
        target: desc(this), topmost: desc(hit)});
}"""


async def _eval_or_raise(client: CDPClient, js: str, what: str):
    result = await client.send('Runtime.evaluate', {
        'expression': js, 'awaitPromise': False, 'returnByValue': True,
    })
    if 'exceptionDetails' in result.get('result', {}):
        desc = result['result']['exceptionDetails'].get('exception', {}).get('description', '')
        raise RuntimeError(f'{what} failed: {desc}')
    return result.get('result', {}).get('result', {}).get('value')


async def _send_or_raise(client: CDPClient, method: str, params: dict, what: str) -> dict:
    """client.send returns CDP errors as {'error': ...}; make them loud."""
    r = await client.send(method, params)
    if r.get('error'):
        err = r['error']
        raise RuntimeError(f'{what}: {method} failed: {err.get("message", err)}')
    return r


async def _object_for(client: CDPClient, selector: str, by_text: bool, what: str) -> str:
    """Resolve a ref, CSS selector or visible text to a remote objectId."""
    if REF_PATTERN.match(selector):
        return await _resolve_ref(client, selector)
    if by_text:
        js = _TEXT_FIND_JS.format(label=json.dumps(selector), mode=json.dumps('element'))
    else:
        js = (f'(() => {{ const el = document.querySelector({json.dumps(selector)});'
              f" if (!el) throw new Error('No element matches: ' + {json.dumps(selector)});"
              f' return el; }})()')
    r = await client.send('Runtime.evaluate', {'expression': js})
    res = r.get('result', {})
    if 'exceptionDetails' in res:
        desc = res['exceptionDetails'].get('exception', {}).get('description', '')
        raise RuntimeError(f'{what} failed: {desc}')
    obj = res.get('result', {})
    if 'objectId' not in obj:
        raise RuntimeError(f'{what} failed: no element for {selector!r}')
    return obj['objectId']


async def _trusted_click(client: CDPClient, object_id: str, target: str) -> dict:
    """Click an element with real input events, so the page sees a user gesture.

    A JS el.click() is untrusted: popups (target=_blank, window.open, most
    "Sign in with ..." buttons), clipboard writes, file pickers and fullscreen
    all ignore it, and passe used to report success anyway. CDP mouse events
    are trusted, but a background tab (passe's default) is not hit-tested
    until it believes it has focus, so focus emulation goes on for the click
    and off again after. That keeps the human's foreground tab where it is,
    unlike Page.bringToFront. Measured on Chrome 158 (atelier, 22 Nov 2026):
    without focus emulation the events were accepted and nothing happened.
    Returns {'topmost': ...} when something other than the target (or one of
    its descendants) was under the point: a <label> over a hidden file input
    is legitimate, a cookie overlay is not, so it is reported, not refused.
    """
    r = await client.send('Runtime.callFunctionOn', {
        'objectId': object_id, 'functionDeclaration': _TRUSTED_PREP_FN,
        'returnByValue': True})
    res = r.get('result', {})
    if r.get('error') or 'exceptionDetails' in res:
        raise RuntimeError(f'click --trusted {target}: could not measure the element '
                           f'({r.get("error") or res.get("exceptionDetails")})')
    info = json.loads(res['result']['value'])
    if info.get('err'):
        raise RuntimeError(f'click --trusted {target}: the element {info["err"]}')
    if not info['in_view']:
        raise RuntimeError(
            f'click --trusted {target}: its centre ({info["x"]:.0f}, {info["y"]:.0f}) '
            'is outside the viewport, so a real click would land on nothing')
    x, y = info['x'], info['y']
    await _send_or_raise(client, 'Emulation.setFocusEmulationEnabled',
                         {'enabled': True}, 'click --trusted')
    try:
        await _send_or_raise(client, 'Input.dispatchMouseEvent',
                             {'type': 'mouseMoved', 'x': x, 'y': y}, 'click --trusted')
        for kind in ('mousePressed', 'mouseReleased'):
            await _send_or_raise(client, 'Input.dispatchMouseEvent', {
                'type': kind, 'x': x, 'y': y, 'button': 'left', 'clickCount': 1},
                'click --trusted')
    finally:
        await client.send('Emulation.setFocusEmulationEnabled', {'enabled': False})
    if not info['on_target']:
        print(f'[click] --trusted: the point over {target} (<{info["target"]}>) '
              f'is covered by <{info["topmost"]}>, which got the click',
              file=sys.stderr)
        return {'topmost': info['topmost']}
    return {}


async def do_click(client: CDPClient, selector: str, trusted: bool = False):
    if trusted:
        oid = await _object_for(client, selector, by_text=False, what='click')
        return await _trusted_click(client, oid, selector)
    if REF_PATTERN.match(selector):
        await _call_on_ref(
            client, selector,
            'function() { this.scrollIntoView({block: "center"}); this.click(); }',
            'click')
        return
    await _eval_or_raise(client, f"""(() => {{
        const el = document.querySelector({json.dumps(selector)});
        if (!el) throw new Error('No element matches: ' + {json.dumps(selector)});
        el.click();
    }})()""", 'click')


async def do_click_text(client: CDPClient, label: str, trusted: bool = False):
    if trusted:
        oid = await _object_for(client, label, by_text=True, what='click-text')
        return await _trusted_click(client, oid, repr(label))
    js = _TEXT_FIND_JS.format(label=json.dumps(label), mode=json.dumps('click'))
    await _eval_or_raise(client, js, 'click-text')


async def do_fill(client: CDPClient, selector: str, value: str):
    js = f'''(() => {{
        const el = document.querySelector({json.dumps(selector)});
        if (!el) throw new Error('No element matches: ' + {json.dumps(selector)});
        el.value = {json.dumps(value)};
        el.dispatchEvent(new Event("input", {{bubbles: true}}));
        el.dispatchEvent(new Event("change", {{bubbles: true}}));
    }})()'''
    result = await client.send('Runtime.evaluate', {
        'expression': js, 'awaitPromise': False
    })
    if 'exceptionDetails' in result.get('result', {}):
        desc = result['result']['exceptionDetails'].get('exception', {}).get('description', '')
        raise RuntimeError(f'fill failed: {desc}')


async def do_type(client: CDPClient, selector: str, text: str):
    from passe.verbs_observation import do_eval

    if REF_PATTERN.match(selector):
        await _call_on_ref(
            client, selector,
            'function() { this.scrollIntoView({block: "center"}); this.focus(); }',
            'type')
        for char in text:
            await client.send('Input.insertText', {'text': char})
        check = await _call_on_ref(
            client, selector, 'function() { return this.value; }', 'type')
        actual = check.get('result', {}).get('result', {}).get('value')
        if actual != text:
            await _call_on_ref(client, selector, f'''function() {{
                this.focus();
                const proto = this.tagName === 'TEXTAREA'
                    ? window.HTMLTextAreaElement.prototype
                    : window.HTMLInputElement.prototype;
                const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
                setter.call(this, {json.dumps(text)});
                this.dispatchEvent(new Event('input', {{ bubbles: true }}));
                this.dispatchEvent(new Event('change', {{ bubbles: true }}));
            }}''', 'type')
            await asyncio.sleep(0.1)
            print('[type] React controlled input detected — used '
                  'nativeInputValueSetter', file=sys.stderr)
        return

    # Focus the element first
    js = f'''(() => {{
        const el = document.querySelector({json.dumps(selector)});
        if (!el) throw new Error('No element matches: ' + {json.dumps(selector)});
        el.focus();
        return true;
    }})()'''
    result = await client.send('Runtime.evaluate', {
        'expression': js, 'awaitPromise': False
    })
    if 'exceptionDetails' in result.get('result', {}):
        desc = result['result']['exceptionDetails'].get('exception', {}).get('description', '')
        raise RuntimeError(f'type focus failed: {desc}')
    # Type each character via CDP Input.insertText (matches Puppeteer).
    # dispatchKeyEvent rawKeyDown/char/keyUp dispatches events but doesn't
    # reliably insert characters. insertText triggers beforeinput + input
    # events which frameworks (React, Vue) pick up correctly.
    for char in text:
        await client.send('Input.insertText', {'text': char})
    # Auto-detect React controlled inputs: if value didn't take, use nativeInputValueSetter
    check_js = f'document.querySelector({json.dumps(selector)}).value'
    actual = await do_eval(client, check_js)
    if actual != text:
        fallback_js = f'''(() => {{
            const el = document.querySelector({json.dumps(selector)});
            el.focus();
            const proto = el.tagName === 'TEXTAREA'
                ? window.HTMLTextAreaElement.prototype
                : window.HTMLInputElement.prototype;
            const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
            setter.call(el, {json.dumps(text)});
            el.dispatchEvent(new Event('input', {{ bubbles: true }}));
            el.dispatchEvent(new Event('change', {{ bubbles: true }}));
        }})()'''
        await client.send('Runtime.evaluate', {
            'expression': fallback_js, 'awaitPromise': False
        })
        # Give React time to reconcile after the synthetic input/change events.
        # Without this, the next verb (e.g. press Enter) fires via CDP before
        # React has updated its internal state from the dispatched events.
        await asyncio.sleep(0.1)
        print(f'[type] React controlled input detected — used nativeInputValueSetter', file=sys.stderr)


async def do_select(client: CDPClient, selector: str, value: str):
    js = f'''(() => {{
        const el = document.querySelector({json.dumps(selector)});
        if (!el) throw new Error('No element matches: ' + {json.dumps(selector)});
        el.value = {json.dumps(value)};
        el.dispatchEvent(new Event("change", {{bubbles: true}}));
    }})()'''
    result = await client.send('Runtime.evaluate', {
        'expression': js, 'awaitPromise': False
    })
    if 'exceptionDetails' in result.get('result', {}):
        desc = result['result']['exceptionDetails'].get('exception', {}).get('description', '')
        raise RuntimeError(f'select failed: {desc}')


async def do_press(client: CDPClient, key: str):
    # Map common key names to CDP key values
    key_map = {
        'enter': ('Enter', '\r', 13),
        'tab': ('Tab', '\t', 9),
        'escape': ('Escape', '', 27),
        'backspace': ('Backspace', '', 8),
        'delete': ('Delete', '', 46),
        'arrowup': ('ArrowUp', '', 38),
        'arrowdown': ('ArrowDown', '', 40),
        'arrowleft': ('ArrowLeft', '', 37),
        'arrowright': ('ArrowRight', '', 39),
        'space': (' ', ' ', 32),
    }
    lower = key.lower()
    if lower in key_map:
        key_name, text, code = key_map[lower]
    else:
        key_name, text, code = key, key, ord(key) if len(key) == 1 else 0

    params = {'type': 'keyDown', 'key': key_name, 'windowsVirtualKeyCode': code}
    if text:
        params['text'] = text
    await client.send('Input.dispatchKeyEvent', params)
    await client.send('Input.dispatchKeyEvent', {
        'type': 'keyUp', 'key': key_name, 'windowsVirtualKeyCode': code
    })


async def do_hover(client: CDPClient, selector: str):
    if REF_PATTERN.match(selector):
        result = await _call_on_ref(client, selector, '''function() {
            this.scrollIntoView({block: "center"});
            const rect = this.getBoundingClientRect();
            return JSON.stringify({x: rect.x + rect.width/2, y: rect.y + rect.height/2});
        }''', 'hover')
        coords = json.loads(result['result']['result']['value'])
        await client.send('Input.dispatchMouseEvent', {
            'type': 'mouseMoved', 'x': coords['x'], 'y': coords['y']
        })
        return
    js = f'''(() => {{
        const el = document.querySelector({json.dumps(selector)});
        if (!el) throw new Error('No element matches: ' + {json.dumps(selector)});
        const rect = el.getBoundingClientRect();
        return JSON.stringify({{x: rect.x + rect.width/2, y: rect.y + rect.height/2}});
    }})()'''
    result = await client.send('Runtime.evaluate', {
        'expression': js, 'awaitPromise': False
    })
    if 'exceptionDetails' in result.get('result', {}):
        desc = result['result']['exceptionDetails'].get('exception', {}).get('description', '')
        raise RuntimeError(f'hover failed: {desc}')
    coords = json.loads(result['result']['result']['value'])
    await client.send('Input.dispatchMouseEvent', {
        'type': 'mouseMoved', 'x': coords['x'], 'y': coords['y']
    })


async def do_tap(client: CDPClient, selector: str):
    """Dispatch real touch events (touchstart + touchend) on element center.

    Uses JS TouchEvent synthesis rather than CDP Input.dispatchTouchEvent
    because the CDP method doesn't respond through flattened sessions
    (browser-level WS + sessionId).  JS synthesis is reliable, portable,
    and fires the same events real touches do.
    """
    js = f'''(() => {{
        const el = document.querySelector({json.dumps(selector)});
        if (!el) throw new Error('No element matches: ' + {json.dumps(selector)});
        const rect = el.getBoundingClientRect();
        const x = rect.x + rect.width / 2;
        const y = rect.y + rect.height / 2;
        const touch = new Touch({{
            identifier: 1, target: el,
            clientX: x, clientY: y, pageX: x, pageY: y
        }});
        el.dispatchEvent(new TouchEvent('touchstart', {{
            touches: [touch], targetTouches: [touch], changedTouches: [touch],
            bubbles: true, cancelable: true
        }}));
        el.dispatchEvent(new TouchEvent('touchend', {{
            touches: [], targetTouches: [], changedTouches: [touch],
            bubbles: true, cancelable: true
        }}));
    }})()'''
    result = await client.send('Runtime.evaluate', {
        'expression': js, 'awaitPromise': False
    })
    if 'exceptionDetails' in result.get('result', {}):
        desc = result['result']['exceptionDetails'].get('exception', {}).get('description', '')
        raise RuntimeError(f'tap failed: {desc}')


async def do_swipe(client: CDPClient, selector: str, direction: str, distance: int = 200) -> dict:
    """Dispatch a touch swipe gesture (touchstart + touchmove sequence + touchend).

    Same JS synthesis approach as do_tap — CDP Input.dispatchTouchEvent
    doesn't work through flattened sessions.

    Returns dict with start/end coordinates for step NDJSON reporting.
    """
    # Direction → (dx, dy) unit vector
    vectors = {'left': (-1, 0), 'right': (1, 0), 'up': (0, -1), 'down': (0, 1)}
    if direction not in vectors:
        raise RuntimeError(f'swipe: unknown direction {direction!r} — use left, right, up, down')
    dx, dy = vectors[direction]
    steps = 8  # intermediate touchmove points for realism
    js = f'''(() => {{
        const el = document.querySelector({json.dumps(selector)});
        if (!el) throw new Error('No element matches: ' + {json.dumps(selector)});
        const rect = el.getBoundingClientRect();
        const cx = rect.x + rect.width / 2;
        const cy = rect.y + rect.height / 2;
        const dx = {dx * distance};
        const dy = {dy * distance};
        const steps = {steps};
        const startX = cx - dx / 2;
        const startY = cy - dy / 2;

        function mkTouch(x, y) {{
            return new Touch({{
                identifier: 1, target: el,
                clientX: x, clientY: y, pageX: x, pageY: y
            }});
        }}

        // touchstart
        const t0 = mkTouch(startX, startY);
        el.dispatchEvent(new TouchEvent('touchstart', {{
            touches: [t0], targetTouches: [t0], changedTouches: [t0],
            bubbles: true, cancelable: true
        }}));

        // touchmove sequence
        for (let i = 1; i <= steps; i++) {{
            const frac = i / steps;
            const t = mkTouch(startX + dx * frac, startY + dy * frac);
            el.dispatchEvent(new TouchEvent('touchmove', {{
                touches: [t], targetTouches: [t], changedTouches: [t],
                bubbles: true, cancelable: true
            }}));
        }}

        // touchend at final position
        const tEnd = mkTouch(startX + dx, startY + dy);
        el.dispatchEvent(new TouchEvent('touchend', {{
            touches: [], targetTouches: [], changedTouches: [tEnd],
            bubbles: true, cancelable: true
        }}));

        return JSON.stringify({{
            startX: Math.round(startX), startY: Math.round(startY),
            endX: Math.round(startX + dx), endY: Math.round(startY + dy)
        }});
    }})()'''
    result = await client.send('Runtime.evaluate', {
        'expression': js, 'awaitPromise': False
    })
    if 'exceptionDetails' in result.get('result', {}):
        desc = result['result']['exceptionDetails'].get('exception', {}).get('description', '')
        raise RuntimeError(f'swipe failed: {desc}')
    return json.loads(result['result']['result']['value'])


async def do_scroll(client: CDPClient, x: int, y: int):
    await client.send('Runtime.evaluate', {
        'expression': f'window.scrollTo({x}, {y})',
        'awaitPromise': False
    })


def _browser_files_mapping() -> tuple[str, str] | None:
    """PASSE_BROWSER_FILES as (local dir, browser dir), or None.

    The mapping belongs to the browser at PASSE_CDP (the atelier writes both
    together). A --cdp override pointing elsewhere is another browser, which
    must not be handed paths in the first one's container.
    """
    import os
    from passe import connection
    mapping = os.environ.get('PASSE_BROWSER_FILES', '')
    if not mapping:
        return None
    override = connection._cdp_override
    if override and override.rstrip('/') != os.environ.get('PASSE_CDP', '').strip().rstrip('/'):
        print(f'[upload] PASSE_BROWSER_FILES ignored: it belongs to PASSE_CDP, '
              f'and this run uses --cdp {override}', file=sys.stderr)
        return None
    host_dir, sep, browser_dir = mapping.rpartition(':')
    if not sep or not host_dir or not browser_dir:
        raise RuntimeError(
            f'PASSE_BROWSER_FILES={mapping!r} is not <local dir>:<browser dir>')
    return os.path.realpath(os.path.expanduser(host_dir)), browser_dir.rstrip('/')


def _sweep_old_upload_dirs(host_dir: str, max_age_s: float = 86400) -> None:
    """Remove passe's own upload staging dirs older than a day."""
    import os
    import shutil
    import time
    now = time.time()
    for name in os.listdir(host_dir):
        if not name.startswith('.passe-upload-'):
            continue
        d = os.path.join(host_dir, name)
        try:
            st = os.lstat(d)
            if (os.path.isdir(d) and not os.path.islink(d)
                    and st.st_uid == os.getuid() and now - st.st_mtime > max_age_s):
                shutil.rmtree(d, ignore_errors=True)
        except OSError:
            pass


def browser_file_paths(paths: list[str]) -> list[tuple[str, str]]:
    """Map local files to the paths the browser opens them by.

    Returns [(local_path, browser_path)]. With no mapping the browser shares
    this filesystem and the two are the same. With PASSE_BROWSER_FILES (the
    atelier's per-home browser: Chrome in a container that sees only that
    directory), a file already inside the local dir is used where it is, and
    any other file is copied into a fresh staging subdirectory, so two files
    with one name don't collide and nothing planted in the shared folder (a
    symlink, written by the browser's own uid) can redirect the copy.
    """
    import os
    import tempfile
    mapping = _browser_files_mapping()
    locals_ = []
    for p in paths:
        given = os.path.abspath(os.path.expanduser(p))
        local = os.path.realpath(given)
        if not os.path.isfile(local):
            raise RuntimeError(f'upload: no such file {p!r}')
        # The shared folder is writable by the browser's uid: a symlink there
        # could point the copy at any file of ours (a key, say) and hand it over.
        if (mapping and os.path.islink(given) and os.path.commonpath(
                [mapping[0], os.path.realpath(os.path.dirname(given))]) == mapping[0]):
            raise RuntimeError(
                f'upload: {p!r} is a symlink inside the shared folder; refusing '
                'to follow it (the browser can write there)')
        locals_.append(local)
    if mapping is None:
        return [(lp, lp) for lp in locals_]
    host_dir, browser_dir = mapping
    pairs, stage = [], None
    for local in locals_:
        if os.path.commonpath([host_dir, local]) == host_dir:
            rel = os.path.relpath(local, host_dir)
            pairs.append((local, f'{browser_dir}/{rel}'))
            continue
        if stage is None:
            _sweep_old_upload_dirs(host_dir)
            stage = tempfile.mkdtemp(prefix='.passe-upload-', dir=host_dir)
            os.chmod(stage, 0o755)  # the browser runs as another uid
        dest = os.path.join(stage, os.path.basename(local))
        try:
            fd = os.open(dest, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
        except FileExistsError:
            raise RuntimeError(
                f'upload: two files are named {os.path.basename(local)!r}; '
                'a browser sees only the name, so rename one')
        with os.fdopen(fd, 'wb') as out, open(local, 'rb') as src:
            os.fchmod(out.fileno(), 0o644)
            while chunk := src.read(1 << 20):
                out.write(chunk)
        rel = os.path.relpath(dest, host_dir)
        print(f'[upload] copied {local} to {dest} (PASSE_BROWSER_FILES)', file=sys.stderr)
        pairs.append((dest, f'{browser_dir}/{rel}'))
    return pairs


# Reads one byte of each chosen file: a path the browser cannot open still
# lands in input.files, with size 0, and fails only when the form is sent.
_UPLOAD_CHECK_FN = '''async function() {
    const out = [];
    for (const f of this.files || []) {
        let err = null;
        try { await f.slice(0, 1).arrayBuffer(); } catch (e) { err = e.name; }
        out.push({name: f.name, size: f.size, err: err});
    }
    return JSON.stringify({tag: this.tagName.toLowerCase(), type: this.type, files: out});
}'''


async def do_upload(client: CDPClient, selector: str, paths: list[str]) -> dict:
    """Set a file input's files, and prove the browser can read each one."""
    import os
    pairs = browser_file_paths(paths)
    object_id = await _object_for(client, selector, by_text=False, what='upload')
    r = await client.send('DOM.setFileInputFiles', {
        'files': [b for _, b in pairs], 'objectId': object_id})
    if r.get('error'):
        raise RuntimeError(
            f'upload: {r["error"].get("message", r["error"])} '
            f'({selector!r} must be an <input type=file>)')
    check = await client.send('Runtime.callFunctionOn', {
        'objectId': object_id, 'functionDeclaration': _UPLOAD_CHECK_FN,
        'awaitPromise': True, 'returnByValue': True})
    res = check.get('result', {})
    if check.get('error') or 'exceptionDetails' in res:
        raise RuntimeError(f'upload: could not read the input back '
                           f'({check.get("error") or res.get("exceptionDetails")})')
    seen = json.loads(res['result']['value'])
    if len(seen['files']) != len(pairs):
        raise RuntimeError(
            f'upload: the input kept {len(seen["files"])} of {len(pairs)} files '
            '(an input without the multiple attribute takes only one)')
    for (local, browser), f in zip(pairs, seen['files']):
        want = os.path.getsize(local)
        if want == 0:
            print(f'[upload] {local} is empty, so the read-back cannot prove the '
                  'browser can open it', file=sys.stderr)
        if f['err'] or f['size'] != want:
            if local == browser:
                hint = ('the browser runs on another filesystem: set '
                        'PASSE_BROWSER_FILES=<local dir>:<browser dir>')
            else:
                hint = ('check PASSE_BROWSER_FILES maps a directory the browser '
                        'has mounted, and that the file is readable by others '
                        '(the browser runs as another uid)')
            raise RuntimeError(
                f'upload: the browser cannot read {browser} '
                f'(size {f["size"]}, want {want}, {f["err"] or "size mismatch"}); {hint}')
    return {'files': [b for _, b in pairs]}
