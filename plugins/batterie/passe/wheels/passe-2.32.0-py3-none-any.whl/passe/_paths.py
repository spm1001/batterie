"""Where passe writes a file when the caller names no path.

A fixed name in the shared temp dir (the old ``/tmp/passe-look.jpg``) is two
bugs on a multi-user host such as the atelier, where eight people share /tmp
under umask 0002: the screenshot of a logged-in page lands world-readable,
and the second person's ``passe look`` cannot overwrite the first person's
file. Defaults therefore go in a per-user directory, mode 0700, that we
refuse to use unless we own it (another account could create the name first).
"""

import os
import stat
import tempfile


def default_output(name: str) -> str:
    """Return a path for ``name`` inside this user's private passe temp dir."""
    uid = os.getuid()
    d = os.path.join(tempfile.gettempdir(), f'passe-{uid}')
    try:
        os.mkdir(d, 0o700)
    except FileExistsError:
        pass
    st = os.lstat(d)
    if not stat.S_ISDIR(st.st_mode) or st.st_uid != uid:
        raise RuntimeError(
            f'{d} exists but is not a directory owned by uid {uid}; '
            'refusing to write output there (pass an explicit path)')
    if stat.S_IMODE(st.st_mode) != 0o700:
        os.chmod(d, 0o700)
    return os.path.join(d, name)
