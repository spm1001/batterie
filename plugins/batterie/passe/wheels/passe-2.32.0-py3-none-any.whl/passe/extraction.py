"""passe's trafilatura call, in one place.

Every Python-side extraction (the HTTP fast-path, the Chrome cascade, the
same-origin iframe descent) and the bench harness call this, so the bench
measures passe's own settings rather than a copy of them (passe-sucewu).
No passe imports: anything may depend on it.
"""

TRAFILATURA_OPTIONS = {
    'include_formatting': True,
    'include_links': True,
    'include_tables': True,
}


def trafilatura_markdown(html: str, url: str | None = None) -> str | None:
    """Markdown from rendered HTML, or None when trafilatura finds nothing.

    trafilatura is imported per call so tests can swap it via sys.modules,
    and so an ImportError surfaces at the caller that handles it.
    """
    import trafilatura
    return trafilatura.extract(html, url=url, **TRAFILATURA_OPTIONS)
