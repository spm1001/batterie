"""sonner — ring a repo, and a Claude answers.

Native cross-session messaging (Claude Code >=2.1.224) delivers between sessions that
are *already running*. There is no store-and-forward and no spawn-on-demand: a message
to a repo nobody is sitting in is simply undeliverable.

sonner closes that gap. Give it a repo and a message:

    sonner ~/repos/spm1001/infra "the deadman for notes-sync went red"

If a live session is already in that repo, the message is delivered to its inbox socket.
If none is, sonner starts one under tmux, waits for its socket, and then delivers the
same message. Either way the receiving Claude sees an ordinary peer message and wakes.

Why spawn-then-deliver rather than passing the text as the new session's prompt: a prompt
reads as the *user* speaking, which invites deference. Delivering over the socket keeps
the peer framing, so the woken Claude treats it as a colleague's note and applies the
harness's own peer guardrails (a peer cannot approve permissions or change config).

    sonner REPO MESSAGE [--from NAME] [--all] [--no-spawn] [--no-stamp] [--work] [--force-spawn]
    sonner --name NAME MESSAGE      # one session by registry name
    sonner --wake REPO [--work] [--force-spawn]  # ensure a session exists; deliver nothing
    sonner --list [--name NAME] [--json]  # every live session, where it is; deaf ones tagged
    sonner --host HOST …            # any of the above, run on HOST via ssh + bash -lic
    sonner --trust [REPO]           # pre-trust REPO (or every ~/repos/*/* git repo)
    sonner --hangup                 # end the calling session, if sonner spawned it

A spawned session stays open by default, for a person to look at. With
--errand, its first message also asks it to /close and `sonner --hangup` once
the errand is done, since nothing else would end it.

Not every live session can be rung. Some write a full registry record with no
messagingSocketPath at all — present and busy, and deaf. (Seen on provider-billed
sessions in August; a claudev session on Vertex binds an inbox as of 30 Sep 2026,
so billing route alone is not the cause.) --list shows those tagged rather than pretending their repo is empty,
and a ring or --wake into a repo held only by deaf sessions is refused rather
than planting a sibling silently; --force-spawn is the explicit, audible override.

A spawn that can never come up fails at once rather than waiting out its timeout:
no claude on PATH, a command that died (its exit status and last screen lines are
reported), or a session parked at the folder-trust dialog — that last one exits 3,
`held:`, and if a message was being rung it has already been delivered and waits.

Rung from a script, sonner hears the receiver's inbound gate: a held message
exits 3 (`held:` — it waits for that user's approval), a refused or dropped one
exits 1. From inside a session it keeps the session's reply address instead,
and says the gate's answer did not come back to it.

Every message carries a timestamp, because Claude Code silently drops a message whose
text is byte-identical to a recent one from the same sender while still reporting
success. A fixed-text heartbeat would vanish with nothing to see. The stamp makes that
class of loss impossible rather than merely documented; --no-stamp opts out.
"""

from __future__ import annotations

import argparse
import errno
import fcntl
import hashlib
import json
import os
import pwd
import shlex
import shutil
import signal
import socket
import subprocess
import sys
import time
import unicodedata
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import NamedTuple

from sonner import __version__, _invlog

# XDG runtime root on systemd Linux — real even when $XDG_RUNTIME_DIR is unset.
_RUN_USER = Path("/run/user")
# Where the binary falls back to when no runtime dir suits it (macOS, long paths).
# A module constant so tests can point it away from the real machine: with it
# hardcoded, a host with live sessions in /tmp/cc-socks leaked ten of them into
# a fixture expecting two.
_TMP = Path("/tmp")

# One tmux session holds every Claude, one window each — the convention
# `claude-start` (dotfiles) has always used. Spawns join it rather than minting
# their own session, so a human has one place to look and one tab bar that lists
# everything. Override for a machine that names its home session differently.
HOME_SESSION = os.environ.get("SONNER_TMUX_SESSION", "claude")

# How a live-but-deaf session is marked wherever one is printed: a registry
# record with no messagingSocketPath, so no inbox exists — present and busy, and
# nothing can ring it. The tag used to say "provider-gated"; a claudev session
# on Vertex binds an inbox (measured 2026-09-30, son-zecece), so billing route
# is not the cause, and the tag no longer names one.
_DEAF_TAG = "[deaf: no inbox]"


class Session(NamedTuple):
    pid: int
    cwd: Path | None  # None: reachable but unplaceable (no record, no /proc)
    socket: Path | None  # None: registered but deaf (no inbox exists)
    name: str
    started: int


def socket_dirs() -> list[Path]:
    """Where sessions bind inbox sockets — the machine-wide ground truth.

    Every session on the machine binds here regardless of which config dir it
    runs under, so this is the roster; registry records are only an enrichment.

    Env vars are hints layered on uid-derived paths, never the only route: a
    caller with a rewritten environment (the receptionnaire mail harness runs
    with XDG_RUNTIME_DIR unset) must still see the whole machine.
    """
    dirs = []
    runtime = os.environ.get("XDG_RUNTIME_DIR")
    if runtime:
        dirs.append(Path(runtime) / "cc-socks")
    dirs.append(_RUN_USER / str(os.getuid()) / "cc-socks")  # the XDG default, env or no env
    dirs.append(_TMP / "cc-socks")  # macOS (verified live: /tmp/cc-socks/<pid>.sock)
    dirs.append(_TMP / f"cc-socks-{os.getuid()}")  # the binary's long-path fallback
    return [d for d in dict.fromkeys(dirs) if d.is_dir()]


def _config_dirs() -> set[Path]:
    """Every Claude Code config dir: ~/.claude, ~/.claude-*, $CLAUDE_CONFIG_DIR,
    under both $HOME and the passwd home (see session_records for why both)."""
    homes = {Path.home()}
    try:
        homes.add(Path(pwd.getpwuid(os.getuid()).pw_dir))
    except KeyError:
        pass  # uid not in the passwd database (containers do this)
    config_dirs: set[Path] = set()
    for home in homes:
        config_dirs.add(home / ".claude")
        config_dirs.update(home.glob(".claude-*"))
    env = os.environ.get("CLAUDE_CONFIG_DIR")
    if env:
        config_dirs.add(Path(env))
    return config_dirs


def session_records() -> dict[int, dict]:
    """Session records by pid, swept across every config dir on the machine.

    Each session writes <pid>.json under ITS OWN config dir's sessions/ — so a
    session running with CLAUDE_CONFIG_DIR=~/.claude-commis registers there, not
    in ~/.claude. Reading only one registry silently hides every session homed in
    another (which is exactly how the first ~/notes/work ring was lost: sonner
    inherited the caller's CLAUDE_CONFIG_DIR and watched the wrong letterbox for
    90 seconds while the spawned session registered in the default one).

    Homes are swept by both routes: $HOME (the caller's world-view) and the
    passwd database (the machine's). They differ exactly when a harness overrode
    HOME — the receptionnaire case — and each may hold registries the other hides.
    """
    return {pid: r for pid, (_, r) in _sweep_records().items()}


def _sweep_records() -> dict[int, tuple[Path, dict]]:
    """session_records(), keeping which config dir (seat) each record came from."""
    records: dict[int, tuple[Path, dict]] = {}
    for config in _config_dirs():
        for record in (config / "sessions").glob("*.json"):
            try:
                r = json.loads(record.read_text())
                records[int(r["pid"])] = (config, r)
            except (OSError, ValueError, KeyError, TypeError):
                continue
    return records


def _pid_reused(pid: int, record: dict) -> bool:
    """True when the record's procStart says pid now belongs to another process.

    Claude Code writes the kernel start-time ticks of its own pid into each
    record. Where /proc can answer (not macOS), a mismatch means the session
    died and its pid was handed on — a crash can leave the socket file behind
    too, so this matters for socketed records as well as deaf ones.
    """
    recorded = record.get("procStart")
    actual = _proc_start_ticks(pid)
    if recorded is None or actual is None:
        return False
    try:
        return int(recorded) != actual
    except (TypeError, ValueError):
        return False  # unparseable procStart: trust the pid, as without /proc


def live_sessions() -> list[Session]:
    """Every reachable session, newest first: sockets for truth, records for names.

    A bound socket whose pid is alive IS a session, whether or not any record
    describes it. The record adds the addressable name and (on machines without
    /proc) the cwd; a record without a socket is a dead session's leavings.
    """
    records = session_records()
    # Scanned dirs catch record-less sessions; records catch sockets bound in a
    # layout we didn't anticipate (each record names its own socket path).
    candidates = {s for d in socket_dirs() for s in d.glob("*.sock")}
    candidates.update(
        Path(r["messagingSocketPath"]) for r in records.values() if "messagingSocketPath" in r
    )
    found = []
    for sock in candidates:
        try:
            pid = int(sock.stem)
            os.kill(pid, 0)
        except (ValueError, ProcessLookupError):
            continue  # not a session socket, or its process is gone
        except PermissionError:
            pass  # alive, just not ours to signal
        if not sock.exists():
            continue  # record named a socket that is already gone

        r = records.get(pid, {})
        if _pid_reused(pid, r):
            continue  # a crashed session's socket file, and its pid is someone else's now
        cwd = r.get("cwd")
        if cwd is None:
            try:
                cwd = os.readlink(f"/proc/{pid}/cwd")
            except OSError:
                pass  # no record and no /proc: reachable but unplaceable
        found.append(
            Session(
                pid=pid,
                cwd=Path(cwd) if cwd else None,
                socket=sock,
                name=r.get("name") or f"pid-{pid}",
                started=int(r.get("startedAt", 0)) or int(sock.stat().st_mtime * 1000),
            )
        )

    found.sort(key=lambda s: s.started, reverse=True)
    return found


def _in_repo(cwd: Path | None, repo: Path) -> bool:
    """Is a session sitting at cwd one that a ring at repo should reach?

    At repo itself, always. Deeper, only inside the same git repo: repo holds
    a .git, and no directory between it and cwd holds one of its own. A
    directory that is not a repo — ~/repos, ~ — therefore matches only a
    session sitting exactly there, and an empty one gets a spawn. The old rule
    (anything below the path) sent a ring at ~/repos, meant to start a fresh
    session, to a lane mid-rename in ~/repos/spm1001/trousse-personal
    (son-lumaki, 2026-09-27). Exact-only was the other candidate; it lost
    because a session started in repo/app would then get a sibling at the root.
    """
    if cwd is None:
        return False
    if cwd == repo:
        return True
    if repo not in cwd.parents or not (repo / ".git").exists():
        return False
    return not any((d / ".git").exists() for d in [cwd, *cwd.parents] if repo in d.parents)


def sessions_in(repo: Path) -> list[Session]:
    """Sessions a ring at repo should reach: at it, or deeper inside the same git repo."""
    return [s for s in live_sessions() if _in_repo(s.cwd, repo)]


def by_name(name: str) -> list[Session]:
    """Sessions matching an addressable registry name — normally zero or one."""
    return [s for s in live_sessions() if s.name == name]


def pick(targets: list[Session], repo: Path) -> list[Session]:
    """The one session a ring should land on: newest, but an exact-cwd match
    beats one buried deeper — ringing /home/modha must reach the session
    sitting there, not whichever repo session under it is newest (2026-08-09).
    """
    exact = [s for s in targets if s.cwd == repo]
    return (exact or targets)[:1]


def _proc_start_ticks(pid: int) -> int | None:
    """The kernel's start time for pid, in clock ticks since boot — None where
    the machine cannot say (no /proc: macOS). Field 22 of /proc/<pid>/stat,
    counted from after the last ')' because comm may itself contain spaces."""
    try:
        with open(f"/proc/{pid}/stat") as f:
            stat = f.read()
        return int(stat.rsplit(")", 1)[1].split()[19])
    except (OSError, IndexError, ValueError):
        return None


def registered_alive() -> list[Session]:
    """Every alive REGISTERED session on the machine — the deaf included.

    The socket roster cannot see a deaf session (no inbox ever binds),
    and waking a repo that holds one would plant a sibling beside it silently.
    Five of eight live sessions on tube were deaf when this was measured
    (2026-08-09), so this is the common case, not the corner.

    A record can be in three states, and only two of them are sessions:

      messagingSocketPath present, socket exists, pid alive -> live, ringable
      messagingSocketPath ABSENT, pid alive                 -> live but deaf
      messagingSocketPath present, socket gone              -> a dead session's leavings

    The deaf case has nothing but the pid to vouch for it, and pids are reused
    — after a reboot every stale record's pid may belong to some other process,
    which would read as a deaf Claude in a repo nobody is in. Claude Code writes
    `procStart` (the kernel's start-time ticks for its own pid) into each
    record; where /proc can answer, a mismatch means the pid is someone else's
    now and the record is leavings. Where it cannot (macOS), the pid is trusted.
    """
    out = []
    for pid, r in session_records().items():
        cwd = r.get("cwd")
        if not cwd:
            continue
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            continue
        except PermissionError:
            pass  # alive, just not ours to signal
        sock = r.get("messagingSocketPath")
        if sock and not Path(sock).exists():
            continue  # the session bound an inbox once and has since gone
        if _pid_reused(pid, r):
            continue  # pid reused since this record was written
        out.append(
            Session(
                pid=pid,
                cwd=Path(cwd),
                socket=Path(sock) if sock else None,
                name=r.get("name") or f"pid-{pid}",
                started=int(r.get("startedAt", 0)),
            )
        )
    return out


def registered_alive_in(repo: Path) -> list[Session]:
    """registered_alive() narrowed by the same rule as sessions_in()."""
    return [s for s in registered_alive() if _in_repo(s.cwd, repo)]


def deaf_sessions() -> list[Session]:
    """Live sessions with no inbox anywhere on the machine, newest first — the
    class the socket roster structurally cannot show. Keyed on the field Claude
    Code itself omits when a session has no inbox, not on anything a session
    asserts about itself."""
    return sorted((s for s in registered_alive() if s.socket is None), key=lambda s: s.started, reverse=True)


def _window_id(record: dict) -> str | None:
    """The @window id from a record's tmux field ('claude:@24.%24' -> '@24').

    Only the id is durable: the session-name half is a snapshot from
    registration, and a stale target resolves to nothing while tmux exits 0
    (measured 2026-08-10)."""
    tmux = record.get("tmux")
    if not isinstance(tmux, str):
        return None
    for part in tmux.rsplit(":", 1)[-1].split("."):
        if part.startswith("@") and part[1:].isdigit():
            return part
    return None


def _window_places() -> dict[str, str]:
    """window id -> 'session:index', read live from the default tmux server.
    Empty when there is no tmux or no server — then ids print unresolved."""
    if shutil.which("tmux") is None:
        return {}
    out = subprocess.run(
        ["tmux", "list-windows", "-a", "-F", "#{window_id} #{session_name}:#{window_index}"],
        capture_output=True, text=True,
    )
    if out.returncode != 0:
        return {}  # no server running
    return dict(line.split(" ", 1) for line in out.stdout.splitlines() if " " in line)


def roster() -> list[dict]:
    """Every live session, newest first, as one dict each: the registry record's
    own fields, plus seat (the config dir it registered under, None when no
    record exists), socket_live, and tmux_window (the durable @id, or None).

    The one roster the human table, --json and any other renderer derive from
    (son-wubuja): sockets for the ringable, records for the deaf, each pid once.
    """
    sweep = _sweep_records()
    sessions = live_sessions()
    socketed = {s.pid for s in sessions}
    deaf = [s for s in deaf_sessions() if s.pid not in socketed]
    rows = []
    for s in sorted([*sessions, *deaf], key=lambda s: s.started, reverse=True):
        seat, record = sweep.get(s.pid, (None, {}))
        rows.append({
            **record,
            "pid": s.pid,
            "name": s.name,
            "cwd": str(s.cwd) if s.cwd else None,
            "seat": str(seat) if seat else None,
            "socket_live": s.socket is not None,
            "tmux_window": _window_id(record),
        })
    return rows


def _jump_line(window: str) -> str:
    """A command that puts the reader in front of that window: switch-client
    inside tmux (attach refuses to nest), attach from outside. Both take a bare
    @id and move to whichever session holds the window now (measured on a
    private tmux 3.5a server, 2026-09-30)."""
    verb = "switch-client" if os.environ.get("TMUX") else "attach"
    return f"tmux {verb} -t {window}"


def _ppid(pid: int) -> int | None:
    try:
        with open(f"/proc/{pid}/status") as f:
            for line in f:
                if line.startswith("PPid:"):
                    return int(line.split()[1])
    except OSError:
        pass
    try:  # macOS has no /proc
        out = subprocess.run(["ps", "-o", "ppid=", "-p", str(pid)], capture_output=True, text=True)
        return int(out.stdout.strip()) if out.stdout.strip() else None
    except (ValueError, OSError):
        return None


def calling_session() -> Session | None:
    """The session sonner is running inside, found by walking up the process tree.

    Lets a ring carry a reply address the receiver can actually use — or an
    honest warning that none exists. Stops above pid 1: init is never a session.
    """
    records = session_records()
    pid: int | None = os.getppid()
    for _ in range(20):
        if pid is None or pid <= 1:
            return None
        r = records.get(pid)
        if r is not None:
            sock = r.get("messagingSocketPath")
            return Session(
                pid=pid,
                cwd=Path(r["cwd"]) if r.get("cwd") else None,
                socket=Path(sock) if sock else None,
                name=r.get("name") or f"pid-{pid}",
                started=int(r.get("startedAt", 0)),
            )
        pid = _ppid(pid)
    return None


_NO_REPLY = (
    "[sonner: sent from a session with no reachable inbox — do not attempt a reply; "
    "act on this message or ignore it]"
)


def _encode_from(value: str) -> str:
    """Percent-encode a `from` value the way Claude Code does (its R(), 2.1.285).

    CC parses <cross-session-message> attributes, re-renders the tag and drops
    the WHOLE framing unless the two are byte-identical; `from` must match
    [A-Za-z0-9%:_/.-]{1,300}. A --from with an @ or a space used to void the
    tag silently — the receiver saw "an unidentified session" (son-hokali).
    """
    return "".join(
        c if (c.isascii() and (c.isalnum() or c in ":_/.-"))
        else "".join(f"%{b:02X}" for b in c.encode())
        for c in value
    )[:300]


def _clean_name(value: str) -> str:
    """from-name exactly as Claude Code would re-render it (its lh(), 2.1.285):
    quotes and angle brackets dropped, format/control/separator characters
    removed, trimmed, and cut to 64 code points with an ellipsis. Anything CC
    would change voids the tag, so sonner sends what CC would produce."""
    kept = "".join(
        c for c in value.replace('"', "").replace("<", "").replace(">", "")
        if unicodedata.category(c) not in ("Cf", "Cc", "Cs", "Zl", "Zp")
    ).strip()
    return kept if len(kept) <= 64 else kept[:64] + "\u2026"


def _transcripts(record: dict) -> list[Path]:
    """The transcript file(s) of the session a registry record describes."""
    sid = record.get("sessionId")
    if not sid:
        return []
    return [path for config in _config_dirs() for path in (config / "projects").glob(f"*/{sid}.jsonl")]


def _transcript_mode(record: dict) -> str | None:
    """The calling session's permission class, from its own transcript.

    The registry record carries no mode, but CC appends a
    {"type":"permission-mode","permissionMode":…} line to the transcript at
    each change (measured 2.1.285). bypassPermissions is "bypass"; every other
    mode asks before some tools, so "prompting". None when the transcript
    cannot be found — then nothing is attested, rather than guessed. An
    unofficial surface: test_mode_is_read_from_the_transcript pins it.
    """
    for path in _transcripts(record):
        try:
            with path.open("rb") as f:
                f.seek(0, os.SEEK_END)
                size = f.tell()
                f.seek(max(0, size - 4_000_000))
                lines = f.read().splitlines()
        except OSError:
            continue
        for line in reversed(lines):
            if b'"permission-mode"' not in line:
                continue
            try:
                mode = json.loads(line).get("permissionMode")
            except ValueError:
                continue
            if mode:
                return "bypass" if mode == "bypassPermissions" else "prompting"
    return None


def sender_identity(explicit: str | None) -> tuple[str, str, str | None, str | None]:
    """(display name, from address, no-reply footer, mode) for an outgoing ring.

    A receiver, unable to resolve script:sonner-3d, once guessed and posted its
    reply through the most sonner-looking letterbox on the machine (2026-08-09).
    So a bare name goes in `from` only when that name can actually receive;
    otherwise the address keeps its script: prefix and the body says don't reply.

    The mode is the calling session's real permission class, and None for a
    script — a script has no mode to attest, and saying "prompting" for every
    sender (as sonner did until son-hokali) was a lie a bypass receiver could
    hold on as a mode mismatch.
    """
    caller = calling_session()
    mode = _transcript_mode(session_records().get(caller.pid, {})) if caller else None
    if caller and caller.socket is not None:
        return explicit or caller.name, caller.name, None, mode
    display = explicit or (caller.name if caller else "sonner")
    return display, f"script:{display}", _NO_REPLY, mode


def _framed(body: str, sender: str, from_addr: str, mode: str | None = None) -> str:
    """The peer framing a receiver acts on, in the exact bytes Claude Code
    would render for the same fields — attribute order from, from-name,
    from-mode — so its byte-equality check keeps the tag."""
    attrs = [f'from="{_encode_from(from_addr)}"']
    name = _clean_name(sender)
    if name:
        attrs.append(f'from-name="{name}"')
    if mode in ("bypass", "prompting"):
        attrs.append(f'from-mode="{mode}"')
    return f"<cross-session-message {' '.join(attrs)}>\n{body}\n</cross-session-message>"


# What a receiver's inbound gate can say back (claude 2.1.286): at the gate,
# held / refused / dropped; later, for a held message, delivered / denied /
# expired. An accepted message gets no receipt at all.
_RECEIPT_STATUSES = ("held", "refused", "dropped", "denied", "expired", "delivered")
# The gate answers within milliseconds (a hold receipt came back in 32ms,
# measured 2026-09-30), so silence after this long means it accepted.
_RECEIPT_WINDOW = 1.0


def _read_receipt(srv: socket.socket, msg_id: str, window: float) -> dict | None:
    """The first peer_message_status for msg_id to arrive within window, or None."""
    deadline = time.monotonic() + window
    while (left := deadline - time.monotonic()) > 0:
        srv.settimeout(left)
        try:
            conn, _ = srv.accept()
        except (socket.timeout, TimeoutError):
            return None
        with conn:
            conn.settimeout(max(0.1, deadline - time.monotonic()))
            data = b""
            try:
                while not data.endswith(b"\n"):
                    chunk = conn.recv(65536)
                    if not chunk:
                        break
                    data += chunk
            except (socket.timeout, TimeoutError):
                pass
        for line in data.splitlines():
            try:
                frame = json.loads(line)
            except ValueError:
                continue
            if (frame.get("action") == "peer_message_status" and frame.get("orig_msg_id") == msg_id
                    and frame.get("status") in _RECEIPT_STATUSES):
                return frame
    return None


def _bind_receipt_socket(sock_path: Path, sender: str) -> tuple[socket.socket, Path] | None:
    """A listening socket beside the receiver's, for its gate receipt — or None,
    with the reason said, when one cannot be had.

    The name is stable per sender and receiver, never per ring. Claude Code's
    admission guard keys a sender by its `from`, so a fresh address per ring
    would make every script ring a first-time sender and switch off the
    receiver's rate limit and duplicate drop (cold review, 2026-09-30); a
    stable one keeps them, as `script:NAME` did. Two rings racing for one name
    (the repo lock covers repo rings, not --name) make the loser ring without a
    receipt rather than steal the socket.
    """
    digest = hashlib.sha1(f"{sender}\0{sock_path}".encode()).hexdigest()[:10]
    rcpt = sock_path.parent / f"sonner-{digest}.sock"
    srv = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        try:
            srv.bind(str(rcpt))
        except OSError as e:
            if e.errno != errno.EADDRINUSE:
                raise
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as probe:
                try:
                    probe.connect(str(rcpt))
                except OSError:
                    rcpt.unlink(missing_ok=True)  # a dead run's leftover (SIGKILL): reclaim it
                else:
                    raise OSError(errno.EADDRINUSE, "another sonner is listening on it") from None
            srv.bind(str(rcpt))
        srv.listen(4)
    except OSError as e:
        srv.close()
        print(f"note: no receipt socket at {rcpt} ({e.strerror or e}) — ringing without one, "
              "so a hold at the far end would not be reported", file=sys.stderr)
        return None
    return srv, rcpt


def deliver(sock_path: Path, body: str, sender: str, from_addr: str | None = None,
            mode: str | None = None, receipt_window: float | None = None) -> dict | None:
    """Write one message envelope to a session's inbox socket.

    The wire format is a single line of JSON. `from` is sender-authored — Claude Code
    keys real identity on the kernel-verified pid of the connecting process, so this
    field is for reply routing and display only.

    With receipt_window, sonner listens for the receiver's gate receipt and
    returns it (None: none came). Claude Code sends a receipt only to a `uds:`
    reply address inside the receiver's own socket directory, and only to a
    listener owned by the process that delivered — so sonner binds a socket
    beside the receiver's and names it as `from`. That address stops existing
    when sonner exits, which is why this is only for callers with no reply
    address of their own (son-tezivo).
    """
    bound = _bind_receipt_socket(sock_path, sender) if receipt_window else None
    if bound:
        from_addr = f"uds:{bound[1]}"
    from_addr = from_addr or f"script:{sender}"
    envelope = {
        "msgV": 1,
        "msg_id": str(uuid.uuid4()),
        "type": "user",
        "message": {
            "role": "user",
            "content": _framed(body, sender, from_addr, mode),
        },
        "priority": "next",
        "from": _encode_from(from_addr),
    }
    # SIGTERM (a harness timeout) and SIGHUP (a dropped --host ssh) would skip
    # the finally below and leave the socket behind; make them unwind instead.
    previous = {}
    if bound:
        for sig in (signal.SIGTERM, signal.SIGHUP):
            try:
                previous[sig] = signal.signal(sig, lambda n, f: sys.exit(128 + n))
            except ValueError:
                pass  # not the main thread: the stable name lets the next run reclaim it
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
            s.connect(str(sock_path))
            s.sendall((json.dumps(envelope) + "\n").encode())
        if not bound:
            return None
        receipt = _read_receipt(bound[0], envelope["msg_id"], receipt_window)
        if receipt and receipt.get("status") == "expired" and receipt.get("status_detail") == "refused":
            receipt = {**receipt, "status": "refused"}  # CC's own spelling of a refusal (2.1.286)
        return receipt
    finally:
        if bound:
            bound[0].close()
            bound[1].unlink(missing_ok=True)
            for sig, handler in previous.items():
                signal.signal(sig, handler)


def _state_dir() -> Path:
    """sonner's own state (locks, spawn records), under the passwd home rather
    than $HOME, so a harness that rewrote HOME still shares it with the user."""
    try:
        home = Path(pwd.getpwuid(os.getuid()).pw_dir)
    except KeyError:
        home = Path.home()
    return home / ".local" / "state" / "sonner"


def _spawn_dir() -> Path:
    d = _state_dir() / "spawned"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _prune_spawn_records() -> None:
    """Drop records whose pid is gone or now belongs to another process, and
    pending-window records whose window no longer exists."""
    live_windows = None
    for old in _spawn_dir().glob("*.json"):
        try:
            rec = json.loads(old.read_text())
        except (OSError, ValueError):
            old.unlink(missing_ok=True)
            continue
        if old.stem.startswith("window-"):
            if live_windows is None:
                live_windows = set(_window_places())
            if rec.get("window") not in live_windows:
                old.unlink(missing_ok=True)
            continue
        try:
            os.kill(int(old.stem), 0)
        except ProcessLookupError:
            old.unlink(missing_ok=True)
            continue
        except (ValueError, PermissionError):
            continue
        if _pid_reused(int(old.stem), rec):
            old.unlink(missing_ok=True)


def _record_spawn(session: "Session", window: str, repo: Path, errand: bool = False) -> None:
    """Remember that sonner started this session — what --hangup checks — and
    whether it was started as an errand, which decides whether its first ring
    carries the close-and-hang-up footer (told records that it has).

    The registry's sessionId is kept beside the pid: on macOS there is no
    procStart to catch a reused pid, and the sessionId catches it anywhere.
    """
    _prune_spawn_records()
    record = session_records().get(session.pid, {})
    (_spawn_dir() / f"{session.pid}.json").write_text(json.dumps({
        "pid": session.pid, "procStart": _proc_start_ticks(session.pid),
        "sessionId": record.get("sessionId"),
        "repo": str(repo), "window": window, "name": session.name,
        "errand": errand, "told": False,
        "at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }))


def _record_pending_window(window: str, repo: Path, errand: bool = False) -> None:
    """A spawn held at the trust dialog before any socket bound (the Mac's
    shape): no pid yet, so remember the window, and adopt whichever session
    later turns out to live in it (_adopt_pending)."""
    _prune_spawn_records()
    (_spawn_dir() / f"window-{window.lstrip('@')}.json").write_text(json.dumps({
        "window": window, "repo": str(repo), "errand": errand,
        "at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }))


def _adopt_pending(session: "Session") -> dict | None:
    """Promote a pending-window record to a spawn record for the session now
    running in that window, if there is one."""
    for f in _spawn_dir().glob("window-*.json"):
        try:
            rec = json.loads(f.read_text())
        except (OSError, ValueError):
            continue
        pane = _pane_pid(rec.get("window", ""))
        if pane is not None and _descends_from(session.pid, pane):
            _record_spawn(session, rec["window"], Path(rec["repo"]), errand=bool(rec.get("errand")))
            f.unlink(missing_ok=True)
            return _spawned_by_sonner(session.pid)
    return None


def _spawned_by_sonner(pid: int) -> dict | None:
    """The spawn record for pid, if sonner started it and the pid is still that
    session: procStart matches where /proc can say, and the registry's
    sessionId matches where both are known. None otherwise."""
    try:
        rec = json.loads((_spawn_dir() / f"{pid}.json").read_text())
    except (OSError, ValueError):
        return None
    if _pid_reused(pid, rec):
        return None
    now = session_records().get(pid, {}).get("sessionId")
    if rec.get("sessionId") and now and rec["sessionId"] != now:
        return None  # another session has this pid now (macOS has no procStart to say so)
    return rec


def _mark_told(pid: int) -> None:
    f = _spawn_dir() / f"{pid}.json"
    try:
        rec = json.loads(f.read_text())
    except (OSError, ValueError):
        return
    f.write_text(json.dumps({**rec, "told": True}))


def _pane_pid(window: str) -> int | None:
    """The pid of the process a window's pane runs, or None when tmux cannot say."""
    if not window:
        return None
    out = subprocess.run(["tmux", "list-panes", "-a", "-F", "#{window_id} #{pane_pid}"],
                         capture_output=True, text=True)
    for line in (getattr(out, "stdout", "") or "").splitlines():
        wid, _, pid = line.partition(" ")
        if wid == window and pid.isdigit():
            return int(pid)
    return None


def _descends_from(pid: int, ancestor: int) -> bool:
    for _ in range(20):
        if pid == ancestor:
            return True
        parent = _ppid(pid)
        if parent is None or parent <= 1:
            return False
        pid = parent
    return False


def _human_has_typed(record: dict) -> bool | None:
    """Has a person typed into this session? True/False from the transcript's
    origin tags ({"origin":{"kind":"human"}} on a typed prompt, "peer" on a
    delivered message — measured 2.1.286). None when no transcript is found,
    and None when no user turn carries an origin tag at all: a Claude Code
    that stopped writing the tag must make --hangup refuse, not read every
    session as untouched (cold read, 2026-09-30). A spawned session always
    has one tagged turn — the peer message that started its errand."""
    paths = _transcripts(record)
    if not paths:
        return None
    tagged = False
    for path in paths:
        try:
            with path.open("rb") as f:
                for line in f:
                    if b'"origin"' not in line or b'"type":"user"' not in line:
                        continue
                    try:
                        d = json.loads(line)
                    except ValueError:
                        continue
                    if d.get("type") != "user" or not isinstance(d.get("origin"), dict):
                        continue
                    tagged = True
                    if d["origin"].get("kind") == "human":
                        return True
        except OSError:
            return None
    return False if tagged else None


# The line an errand spawn's first message ends with. Nothing else will ever
# end a session sonner started — no human opened it, and a later peer message
# asking it to close was held for approval when tried (2026-08-10) — so the
# errand carries its own ending (son-bamaku). Opt-in with --errand: Sameer
# wants spawns left open to look at by default (2026-10-01). Only for a
# session sonner started, and only once: a session already there is someone's.
_ERRAND_FOOTER = (
    "[sonner: sonner started this session, so nothing else will end it. When the errand "
    "is done and no other messages are waiting, land it the way this repo expects — "
    "/close, if it changed anything worth a handoff — then end the session yourself "
    "with `sonner --hangup`.]"
)
# Long enough for the calling tool call to return and land in the transcript.
_HANGUP_DELAY = 3


def hangup() -> int:
    """End the calling session, if sonner started it and no person has used it.

    Deny by default, three ways. A session sonner did not spawn belongs to
    whoever opened it. One sonner did spawn stops being sonner's the moment a
    person types into it — `claude-start <repo>` attaches to the window named
    for the repo, which is exactly how sonner names its spawns — so a typed
    prompt in the transcript refuses too, as does a transcript that cannot be
    read. SIGTERM is what Claude Code cleans up on (its registry record goes),
    and the tmux window closes with the process, since remain-on-exit is unset
    once a spawn settles. The spawn record goes only after the kill is sent.
    """
    caller = calling_session()
    if caller is None:
        print("hangup: not running inside a Claude Code session — nothing to end", file=sys.stderr)
        return 1
    rec = _spawned_by_sonner(caller.pid) or _adopt_pending(caller)
    if rec is None:
        print(
            f"hangup refused: sonner did not start {caller.name} (pid {caller.pid}), so it "
            "belongs to whoever opened it — they close it, not a peer's errand",
            file=sys.stderr,
        )
        return 1
    typed = _human_has_typed(session_records().get(caller.pid, {}))
    if typed is not False:
        why = ("a person has typed into it, so it is theirs now" if typed
               else "its transcript cannot be read (or carries no origin tags) to check that no "
               "person has typed into it")
        print(f"hangup refused: sonner started {caller.name} (pid {caller.pid}), but {why} "
              "— leave it open", file=sys.stderr)
        return 1
    record_file = _spawn_dir() / f"{caller.pid}.json"
    subprocess.Popen(
        ["sh", "-c", f'sleep {_HANGUP_DELAY}; kill -TERM {caller.pid} && rm -f "$0"', str(record_file)],
        start_new_session=True, stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    print(f"hanging up {caller.name} (pid {caller.pid}) in {caller.cwd} — "
          f"the session ends in {_HANGUP_DELAY}s, and tmux window {rec.get('window')} with it")
    return 0


# Held open for the life of the process: the kernel drops a flock when its
# holder exits, and sonner exits right after delivering, so there is no
# release path to forget.
_HELD_LOCKS: dict[Path, object] = {}


def _hold_repo_lock(repo: Path) -> None:
    """Serialise check-spawn-deliver per repo, until this process exits.

    Two rings into one empty repo both saw nobody home, both opened a window,
    and each took the first new socket as its own: 30 of 30 replay trials
    (docs/dev-rigs/holomi_replay.py) ended with two sessions or a lost ring
    (son-holomi, 2026-09-30). Under the lock the second ring waits for the
    first spawn, then finds that session and delivers to it. Keyed on the
    resolved path; the lock files live in the uid-derived state dir.
    """
    if repo in _HELD_LOCKS:
        return  # re-entrant: a second flock on a fresh descriptor would wait on itself
    locks = _state_dir() / "locks"
    locks.mkdir(parents=True, exist_ok=True)
    f = open(locks / f"{hashlib.sha1(str(repo).encode()).hexdigest()[:16]}.lock", "w")
    try:
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        print(f"waiting: another sonner is ringing or spawning in {repo}", file=sys.stderr)
        fcntl.flock(f, fcntl.LOCK_EX)
    _HELD_LOCKS[repo] = f


def _tmux_spawn(repo: Path, argv: list[str]) -> str:
    """Start argv detached in a window of the home session; return its window id.

    A window, never a session of its own. Sameer's ask, 2026-08-10: one tmux
    session, everything flowing into it. Session-per-spawn had scattered live
    Claudes across three sessions, and since a tmux status bar names only the
    session you are attached to, two of them were invisible from the tab bar.

    The window is named for the repo, which also makes `claude-start <repo>`
    find and reuse it. `-n` at creation is what keeps that name: it disables
    automatic-rename for the window, so tmux does not overwrite it with the
    running command (measured 2026-08-10 — without `-n` the tab reads "claude").
    """
    if shutil.which("tmux") is None:
        raise SystemExit(
            "cold-spawn needs tmux (the spawned session must live in a terminal that "
            "outlasts this command). Install tmux, or pass --no-spawn to fail instead."
        )
    # The window name is the repo's, never "sonner-<repo>": a receiver hunting for
    # sonner's own session once picked a spawned bystander off exactly that name and
    # misdelivered a reply (2026-08-09). Naming a window after its repo is honest —
    # it says where the session is, not who started it.
    #
    # "=" forces an exact session match. Bare "claude" prefix-matches, so a session
    # called "claude-anything" would silently swallow every spawn.
    target = f"={HOME_SESSION}:"
    have_home = subprocess.run(
        ["tmux", "has-session", "-t", f"={HOME_SESSION}"], capture_output=True
    ).returncode == 0
    # -d: do not steal focus from whatever window the human is watching.
    window_cmd = ["tmux", "new-window", "-d", "-t", target, "-n", repo.name]
    session_cmd = ["tmux", "new-session", "-d", "-s", HOME_SESSION, "-n", repo.name]
    # The window opens on a placeholder, and argv arrives by respawn-pane only
    # once remain-on-exit is set on it. Setting the option after new-window with
    # argv loses the race whenever argv dies at once — a command-not-found pane
    # is gone before the next tmux call lands, even chained in one invocation
    # (measured 2026-09-30, tmux 3.5a) — and a vanished window says nothing about
    # why. A dead pane that stays put keeps its exit status and its last screen.
    tail = ["-c", str(repo), "-P", "-F", "#{window_id}", "sleep", "86400"]
    proc = subprocess.run([*(window_cmd if have_home else session_cmd), *tail],
                          capture_output=True, text=True)
    if proc.returncode != 0 and not have_home:
        # Two spawns on a cold machine both saw no home session, and the
        # loser's new-session failed "duplicate session" with its ring lost —
        # join the winner's session instead (son-holomi replay, 2026-09-30).
        proc = subprocess.run([*window_cmd, *tail], capture_output=True, text=True)
    if proc.returncode != 0:
        raise subprocess.CalledProcessError(proc.returncode, proc.args, proc.stdout, proc.stderr)
    # The window id (@N) is the only durable coordinate: it survives the session
    # being renamed and the window being moved between sessions, both of which a
    # "session:window" string does not — and a stale one resolves to nothing while
    # tmux still exits 0 (measured 2026-08-10).
    window = proc.stdout.strip()
    try:
        subprocess.run(
            ["tmux", "set-option", "-w", "-t", window, "remain-on-exit", "on"],
            capture_output=True, check=True,
        )
        subprocess.run(
            ["tmux", "respawn-pane", "-k", "-t", window, "-c", str(repo), *argv],
            capture_output=True, check=True,
        )
    except subprocess.CalledProcessError:
        subprocess.run(["tmux", "kill-window", "-t", window], capture_output=True)
        raise
    return window


# Text only Claude Code's folder-trust dialog puts on screen (claude 2.1.285,
# 2026-09-30). Its default answer is "No, exit". And the inbox socket binds
# ~0.35s into startup, ~0.17s BEFORE the dialog draws (measured, four cold
# starts on tube) — so "the socket is up" does not mean "a Claude is reading".
_TRUST_MARKERS = ("Yes, I trust this folder", "Quick safety check")
# The welcome banner, drawn only once a session is past the trust gate: the
# positive sign that ends the settle wait early (about 1.5s on a cold start).
_BANNER = "Claude Code v"
# How long after readiness to watch for the dialog when the banner never shows.
_SETTLE = 10.0


class HeldAtTrust(Exception):
    """The session came up, but its screen shows the folder-trust dialog.

    The usual shape for a repo never opened interactively. On tube the socket
    binds before the dialog draws, so `session` is set and a message delivered
    now is queued, unread, until someone answers Yes — and lost if they answer
    No. Before this check, sonner printed "woke" and exited 0 there (seen from
    the Mac, 2026-09-30). On the Mac nothing binds until trust is answered, so
    `session` is None and a socket ring has nothing to deliver to.
    """

    def __init__(self, session: "Session | None", window: str, repo: Path):
        super().__init__(session, window, repo)
        self.session = session
        self.window = window
        self.repo = repo
        self.message = False  # set by a ring, so the report can say what happened to it


def _probe(window: str) -> tuple[bool | None, str | None, str]:
    """(dead, how it ended, screen) for a spawned window's pane.

    dead is None when the window no longer exists. "How it ended" reads
    "status N" or "signal N" — a pane killed by a signal has an empty
    pane_dead_status. Looked up by listing rather than by `display -t`,
    because a stale target prints nothing and exits 0.
    """
    listing = subprocess.run(
        ["tmux", "list-panes", "-a", "-F",
         "#{window_id} #{pane_dead} s#{pane_dead_status} g#{pane_dead_signal}"],
        capture_output=True, text=True,
    ).stdout
    for line in listing.splitlines():
        wid, dead, status, signal = (line.split() + ["", "", "s", "g"])[:4]
        if wid == window:
            screen = subprocess.run(
                ["tmux", "capture-pane", "-p", "-t", window], capture_output=True, text=True
            ).stdout
            rows = [r.rstrip() for r in screen.splitlines() if r.strip()]
            ended = (f"status {status[1:]}" if status[1:]
                     else f"signal {signal[1:]}" if signal[1:] else None)
            return dead == "1", ended, "\n".join(rows[-15:])
    return None, None, ""


def _await_session(repo: Path, window: str, ready, timeout: float, awaited: str,
                   settle: float = _SETTLE):
    """Poll ready() until it yields a session past the trust gate; fail at once if it never can.

    Three ways a spawn can go nowhere, each named rather than waited out: the
    command died (status and last screen lines reported, dead window closed),
    the window vanished (closed by hand), or the session is parked at the
    folder-trust dialog (window left open for a human to answer). Once ready()
    answers, the screen is watched until the banner shows or `settle` runs out,
    because the dialog draws just after the socket binds.
    """
    deadline = time.monotonic() + timeout
    settled_by = None
    closed = False
    try:
        while time.monotonic() < deadline:
            session = ready()
            dead, ended, screen = _probe(window)
            if dead:
                subprocess.run(["tmux", "kill-window", "-t", window], capture_output=True)
                closed = True
                hint = " (127: command not found — check PATH)" if ended == "status 127" else ""
                shown = "\n".join(f"  | {r}" for r in screen.splitlines()) or "  (nothing on screen)"
                raise SystemExit(
                    f"spawn failed: the command in tmux window {window} for {repo} exited "
                    f"({ended or 'unknown'}){hint} before {awaited}. Last lines on screen:\n"
                    f"{shown}\n(the dead window has been closed)"
                )
            if dead is None and session is None:
                closed = True
                raise SystemExit(
                    f"spawn failed: tmux window {window} for {repo} vanished before {awaited} "
                    "(closed by hand?)"
                )
            if any(m in screen for m in _TRUST_MARKERS):
                raise HeldAtTrust(session, window, repo)
            now = time.monotonic()
            if session is not None and settled_by is None:
                settled_by = now + settle
                # A session found late still gets its settle, not a false timeout.
                deadline = max(deadline, settled_by + 1)
            if session is not None and (_BANNER in screen or now >= settled_by):
                if _BANNER not in screen:
                    print(
                        f"note: {awaited}, but no welcome banner showed in window {window} "
                        f"within {settle:.0f}s — carrying on, with no trust dialog seen either",
                        file=sys.stderr,
                    )
                return session
            time.sleep(0.25)
        raise TimeoutError(
            f"session started in tmux window {window} but {awaited} did not happen within "
            f"{timeout:.0f}s — see why with 'tmux switch-client -t {window}' from inside "
            f"tmux, or 'tmux attach -t {HOME_SESSION}' from outside"
        )
    finally:
        if not closed:
            # The dead-pane catch has done its job, however this ended; from
            # here a normal exit (or a human answering "No, exit") closes the
            # tab, as it always has.
            subprocess.run(
                ["tmux", "set-option", "-w", "-u", "-t", window, "remain-on-exit"],
                capture_output=True,
            )


def spawn(repo: Path, timeout: float = 180.0, work: bool = False, errand: bool = False) -> Session:
    """Start a session in `repo` under tmux and wait for its inbox socket.

    Returns the new session once it is reachable. The session is left running and
    detached, so it can be attached to later and messaged again. The wait is
    generous because a session start runs hooks and orientation before binding.

    claude is resolved against sonner's own PATH and passed absolute, because
    tmux gives the new window the calling client's PATH: a caller whose PATH
    lacks claude (a bare `ssh HOST sonner …`) used to get a window that exited
    127 in under a second and a silent 180s wait (son-dimohu, 2026-09-30).

    work=True launches `claudev` — MIT work billing on Vertex, Opus 5.5, the
    house model since 2026-09-26 — through an interactive bash, because it is a
    commons-managed shell function, not a binary. It used to launch claudefv
    and treat the session as deaf, with the message left in a file and a
    pointer passed as the prompt. Measured 2026-09-30 (son-zecece): a claudev
    session binds an inbox and answers a ring, so it now gets the same
    socket delivery as any other spawn. If one ever comes up deaf regardless,
    that is said at once rather than waited out.
    """
    if work:
        argv = ["bash", "-ic", "claudev"]
    else:
        claude = shutil.which("claude")
        if claude is None:
            raise SystemExit(
                "spawn failed: no 'claude' on this PATH "
                f"({os.environ.get('PATH', '')}). Run sonner from a login shell — from another "
                "machine, 'sonner --host HOST …' does that for you — or put claude's directory on PATH."
            )
        argv = [claude]
    before = {s.socket for s in live_sessions()}
    before_records = set(session_records())
    window = _tmux_spawn(repo, argv)

    def ours(s: Session) -> bool:
        # A person who opens claude in the same repo during the wait must not
        # be taken for the spawn — its record would license --hangup on their
        # session. Where tmux names the pane's process, the session must
        # descend from it; where it cannot, first-new-socket stands.
        pane = _pane_pid(window)
        return pane is None or _descends_from(s.pid, pane)

    def ready():
        found = next((s for s in sessions_in(repo) if s.socket not in before and ours(s)), None)
        if found is None:
            deaf = [s for s in registered_alive_in(repo)
                    if s.pid not in before_records and s.socket is None and ours(s)]
            if deaf:
                raise SystemExit(
                    f"spawn came up deaf: {deaf[0].name} (pid {deaf[0].pid}) in tmux window "
                    f"{window} registered with no inbox, so nothing can be delivered to it. "
                    "The session is left running."
                )
        return found

    try:
        session = _await_session(repo, window, ready, timeout, "the session bound an inbox socket")
    except HeldAtTrust as held:
        if held.session is not None:
            _record_spawn(held.session, window, repo, errand=errand)
        else:
            _record_pending_window(window, repo, errand=errand)
        raise
    _record_spawn(session, window, repo, errand=errand)
    return session


# A far spawn waits up to 180s for its session; the ssh wait must outlast it,
# or the far side's own error is cut off and the caller learns nothing.
_REMOTE_TIMEOUT = 240.0
# What `bash -i` prints on stderr when it has no terminal — noise, every time.
_BASH_I_NOISE = ("cannot set terminal process group", "no job control in this shell")


def ring_remote(args, argv: list[str]) -> int:
    """Run this same sonner command on args.host, through a login shell there.

    The login shell is the point. A bare `ssh HOST sonner …` gets sshd's PATH
    — on tube /usr/local/bin:/usr/bin:/bin, on the Mac without even sonner or
    tmux — and tmux hands that PATH to the window it spawns, so claude is not
    found (30 Sep 2026, son-tolile). `bash -lic` loads the profile and the
    bashrc, so the far side gets PATH and exports such as
    CLAUDE_CODE_DISABLE_REFUSAL_FALLBACK too.
    """
    # argparse takes any unambiguous prefix (--ho, --hos), and forwarding one
    # would have the far sonner ssh onward again, hop after hop.
    def is_host(tok: str) -> bool:
        flag = tok.split("=", 1)[0]
        return len(flag) >= 4 and "--host".startswith(flag)

    forward, skip = [], False
    for a in argv:
        if skip:
            skip = False
        elif is_host(a):
            skip = "=" not in a
        else:
            forward.append(a)
    # A repo under the local home is almost always the same repo under the far
    # home; the local shell has already expanded ~, so put it back. A relative
    # path means here, not the far home that ssh starts in, so resolve it first.
    if args.repo and not args.name:
        local = str(Path(args.repo).expanduser().resolve()) if not args.repo.startswith("~") else args.repo
        home = str(Path.home())
        if local == home or local.startswith(home + "/"):
            local = "~" + local[len(home):]
        forward[forward.index(args.repo)] = local
    if args.sender is None and not (args.list or args.wake or args.trust):
        display, _, _, _ = sender_identity(None)
        forward += ["--from", f"{display}@{socket.gethostname().split('.')[0]}"]
    remote = "bash -lic " + shlex.quote(shlex.join(["sonner", *forward]))
    try:
        proc = subprocess.run(
            ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=10", args.host, remote],
            capture_output=True, text=True, timeout=_REMOTE_TIMEOUT,
            stdin=subprocess.DEVNULL,  # never swallow the caller's stdin (a `while read` loop)
        )
    except subprocess.TimeoutExpired:
        print(
            f"sonner on {args.host} gave no answer within {_REMOTE_TIMEOUT:.0f}s — "
            f"look there with 'ssh {args.host} tmux attach -t {HOME_SESSION}'",
            file=sys.stderr,
        )
        return 124
    sys.stdout.write(proc.stdout)
    for line in proc.stderr.splitlines():
        if not any(n in line for n in _BASH_I_NOISE):
            print(line, file=sys.stderr)
    if proc.returncode == 255:
        print(f"ssh to {args.host} failed (exit 255) — nothing was sent", file=sys.stderr)
    return proc.returncode


def _config_files() -> list[Path]:
    """Every Claude Code global config on this machine: one per seat.

    ~/.claude.json for the default seat, and <dir>/.claude.json for each
    ~/.claude-* config dir (the commis seat lives in ~/.claude-commis) and
    any $CLAUDE_CONFIG_DIR — trust is recorded per seat, so a repo trusted
    in one still shows the dialog to a session billed on another.
    """
    home = Path.home()
    found = [home / ".claude.json", *sorted(home.glob(".claude-*/.claude.json"))]
    if os.environ.get("CLAUDE_CONFIG_DIR"):
        found.append(Path(os.environ["CLAUDE_CONFIG_DIR"]).expanduser() / ".claude.json")
    return [f for f in dict.fromkeys(found) if f.is_file()]


def trust_repos(repos: list[Path]) -> int:
    """Set projects[repo].hasTrustDialogAccepted in every seat's config.

    Trust is per exact path — a trusted ~ or ~/repos does not cover a repo
    never opened (measured 2026-09-30: dragram on tube, sonner on the Mac) —
    so a spawn into any fresh repo stops at the dialog. Sameer's call, same
    day: pre-trust his own repos. Not done automatically on spawn, because
    the dialog is the one gate against a newly cloned repo's hooks running.

    Running sessions rewrite this file whole (tmp + rename), so the write is
    the same tmp + rename, and each file is re-read afterwards: a session
    that saved in between would have dropped the change, and that is said.
    """
    targets = [str(r) for r in repos]
    status = 0
    for cfg in _config_files():
        data = json.loads(cfg.read_text())
        projects = data.setdefault("projects", {})
        todo = [t for t in targets if not projects.get(t, {}).get("hasTrustDialogAccepted")]
        if not todo:
            print(f"{cfg}: all {len(targets)} already trusted")
            continue
        for t in todo:
            projects.setdefault(t, {})["hasTrustDialogAccepted"] = True
        tmp = cfg.with_name(f"{cfg.name}.sonner-{os.getpid()}")
        tmp.write_text(json.dumps(data, indent=2))
        os.chmod(tmp, cfg.stat().st_mode & 0o777)
        os.replace(tmp, cfg)
        after = json.loads(cfg.read_text()).get("projects", {})
        lost = [t for t in todo if not after.get(t, {}).get("hasTrustDialogAccepted")]
        print(f"{cfg}: trusted {len(todo) - len(lost)} of {len(targets)} "
              f"({len(targets) - len(todo)} were already)")
        for t in todo:
            print(f"  + {t}" if t not in lost else f"  ! {t} — overwritten by a running session; run again")
        status = status or (1 if lost else 0)
    return status


def _say_held(held: HeldAtTrust, delivered: bool) -> None:
    """Report a session parked at the folder-trust dialog — exit 3, never 'woke'."""
    s = held.session
    who = f"{s.name} (pid {s.pid})" if s else "the new session"
    if delivered:
        what = ("the message is waiting for it and will be read once someone answers Yes — "
                "do not ring again, or it arrives twice")
    elif s is None and held.message:
        what = ("it binds no inbox until then, so nothing was delivered — answer it, "
                "then run the same sonner command again")
    else:
        what = "it will not start work until someone answers"
    print(
        f"held: {who} in {held.repo} is at Claude Code's folder-trust dialog "
        f"(default 'No, exit'); {what}. Answer it in tmux window {held.window} — "
        f"'tmux attach -t {HOME_SESSION}', window {held.repo.name}. To skip the dialog next "
        f"time: sonner --trust {held.repo}",
        file=sys.stderr,
    )


class _ReturnCode(SystemExit):
    """Sentinel for main()'s return-int contract, below — never raised by
    anything else."""


def main() -> int:
    """Entry point: invocation logging around the real main.

    Every invocation — success and failure alike — appends one caller-stamped
    JSONL line via the vendored shim (src/sonner/_invlog.py; canonical copy
    and cross-estate conformance test live in spm1001/harness-ergonomics).

    sonner's idiom is return-int, not sys.exit — tests assert on the return
    value, and p.error() SystemExits must still propagate. The shim's capture
    derives exit codes from exceptions only, so a plain wrap would log every
    returned failure code as ok. Bridge: raise the return value as a private
    SystemExit subclass inside the capture (the shim logs its true code) and
    unwrap only that sentinel here, re-raising everything genuine. Logging is
    best-effort: a broken log path never breaks the CLI (erg-tebapi).
    """
    try:
        with _invlog.capture("sonner", __version__) as inv:
            raise _ReturnCode(_main(inv))
    except _ReturnCode as e:
        return e.code if isinstance(e.code, int) else 0


def _main(inv) -> int:
    p = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    p.add_argument("repo", nargs="?", help="repo to ring")
    p.add_argument("message", nargs="?", help="what to say")
    p.add_argument("--name", help="ring a specific session by registry name instead of a repo")
    p.add_argument(
        "--from",
        dest="sender",
        default=None,
        help="sender name shown to the receiver (default: the calling session's own name)",
    )
    p.add_argument("--all", action="store_true", help="ring every session in the repo, not just the newest")
    p.add_argument("--no-spawn", action="store_true", help="fail rather than start a session")
    p.add_argument("--wake", action="store_true", help="ensure a session exists in REPO — deliver nothing")
    p.add_argument(
        "--work",
        action="store_true",
        help="spawn on MIT work billing (claudev: Opus 5.5 on Vertex); it gets an inbox like any other",
    )
    p.add_argument(
        "--no-stamp",
        dest="stamp",
        action="store_false",
        help="omit the timestamp — only for one-off messages you will never repeat",
    )
    p.add_argument(
        "--force-spawn",
        action="store_true",
        help="spawn beside a live-but-deaf session instead of refusing (the deaf one stays; "
        "you get a sibling)",
    )
    p.add_argument(
        "--errand",
        action="store_true",
        help="a session sonner starts for this ring (or --wake) is for one errand: its first "
        "message asks it to /close and `sonner --hangup` when done. Without it, spawns stay open",
    )
    p.add_argument(
        "--hangup",
        action="store_true",
        help="end the calling session — only one sonner started; any other is refused",
    )
    p.add_argument(
        "--list",
        action="store_true",
        help="show every live session and exit — deaf ones (no inbox) annotated",
    )
    p.add_argument(
        "--json",
        action="store_true",
        help="with --list: one JSON object per live session — the full registry record plus "
        "seat, socket_live and tmux_window",
    )
    p.add_argument(
        "--host",
        help="run this sonner command on another machine, over ssh through a login shell "
        "(REPO is a path there; one under your home here is sent as ~/…)",
    )
    p.add_argument(
        "--trust",
        action="store_true",
        help="mark REPO trusted in Claude Code's config, so a spawn there skips the folder-trust "
        "dialog; with no REPO, every git repo under ~/repos/*/*",
    )
    args = p.parse_args()
    # No subparsers — the verbs are flag-selected, in dispatch order.
    # --name rings stay "ring"; parsed carries the name for finer analysis.
    mode = ("list" if args.list else "wake" if args.wake else "trust" if args.trust
            else "hangup" if args.hangup else "ring")
    inv.note(subcommand=mode, parsed=args)

    if args.json and not args.list:
        p.error("--json goes with --list")
    if args.force_spawn and args.no_spawn:
        p.error("--force-spawn and --no-spawn contradict each other")

    if args.hangup:
        extras = [args.repo, args.name, args.wake, args.list, args.trust, args.host, args.all,
                  args.work, args.errand, args.sender, args.force_spawn, args.no_spawn, args.json]
        if any(extras) or not args.stamp:
            p.error("--hangup takes nothing else — it ends the session it runs in")
        return hangup()

    if args.host:
        return ring_remote(args, sys.argv[1:])

    if args.trust:
        if args.message or args.name or args.wake or args.list:
            p.error("--trust takes at most a repo — nothing else")
        if args.repo:
            repos = [Path(args.repo).expanduser().resolve()]
            if not repos[0].is_dir():
                print(f"not a directory: {repos[0]}", file=sys.stderr)
                return 2
        else:
            repos = sorted(r.parent for r in (Path.home() / "repos").glob("*/*/.git"))
        return trust_repos(repos)

    if args.list:
        rows = roster()
        if args.name:
            rows = [r for r in rows if r["name"] == args.name]
        if args.json:
            print(json.dumps(rows, indent=2))
            return 0 if rows or not args.name else 1
        if not rows:
            print(f"no session named {args.name!r}" if args.name else "no sessions")
            return 1 if args.name else 0
        # WHERE: the window's live place in tmux when the server knows it,
        # the bare @id when it does not, "-" for a session outside tmux
        # (a remote-control child, a background job) — reachable only through
        # whatever started it.
        places = _window_places()
        width = max(20, *(len(r["name"]) for r in rows))
        for r in rows:
            w = r["tmux_window"]
            where = (places.get(w) or w) if w else "-"
            tag = "" if r["socket_live"] else f"  {_DEAF_TAG}"
            print(f"{r['name']:<{width}} {r['pid']:>8}  {where:<10} {r['cwd']}{tag}")
        if args.name:
            for r in rows:
                if r["tmux_window"]:
                    print(_jump_line(r["tmux_window"]))
                else:
                    print(f"{r['name']} is not in a tmux window — nothing to jump to", file=sys.stderr)
        deaf = [r for r in rows if not r["socket_live"]]
        if deaf:
            print(
                f"{len(deaf)} deaf: live but no inbox exists — a ring at "
                "their repo is refused rather than spawning a sibling; --force-spawn overrides",
                file=sys.stderr,
            )
        return 0

    if args.wake:
        if args.message or args.name:
            p.error("--wake delivers nothing — drop the message/--name (or ring without --wake)")
        if not args.repo:
            p.error("--wake needs a repo")
        repo = Path(args.repo).expanduser().resolve()
        if not repo.is_dir():
            print(f"not a directory: {repo}", file=sys.stderr)
            return 2
        # Union of both rosters: sockets miss the deaf, records are the guard
        # against planting a sibling beside a live work session.
        _hold_repo_lock(repo)
        existing = {s.pid: s for s in registered_alive_in(repo)}
        for s in sessions_in(repo):
            existing.setdefault(s.pid, s)
        deaf_only = bool(existing) and all(s.socket is None for s in existing.values())
        if existing and not (args.force_spawn and deaf_only):
            for s in existing.values():
                tag = "" if s.socket else f" {_DEAF_TAG}"
                print(f"already awake: {s.name} (pid {s.pid}) in {s.cwd}{tag}")
            if args.force_spawn:
                print(
                    "--force-spawn ignored: a session with an inbox is already here",
                    file=sys.stderr,
                )
            elif deaf_only:
                print(
                    "nothing can ring it; --force-spawn plants a sibling beside it anyway",
                    file=sys.stderr,
                )
            return 0
        for s in existing.values():
            print(
                f"live but deaf: {s.name} (pid {s.pid}) in {s.cwd} — spawning a sibling "
                "beside it as asked (--force-spawn)",
                file=sys.stderr,
            )
        try:
            s = spawn(repo, work=args.work, errand=args.errand)
        except HeldAtTrust as held:
            _say_held(held, delivered=False)
            return 3
        print(f"woke {s.name} (pid {s.pid}) in {s.cwd}")
        return 0

    if args.work and args.name:
        p.error("--work spawns into a repo — it cannot be combined with --name")
    if args.force_spawn and args.name:
        p.error("--force-spawn spawns into a repo — it cannot be combined with --name")

    if args.name:
        # `sonner --name NAME "msg"`: the message lands in the repo slot.
        if args.repo and args.message:
            p.error("with --name, give just the message — no repo")
        if args.all:
            p.error("--all applies to repo rings, not --name")
        args.message = args.message or args.repo
        if not args.message:
            p.error("--name needs a message")
    elif not args.repo or not args.message:
        p.error("repo and message are both required (or use --list / --name)")

    display, from_addr, footer, mode = sender_identity(args.sender)

    stamp = f"[{datetime.now(timezone.utc).isoformat(timespec='milliseconds')}]" if args.stamp else None

    def send(target: Session) -> None:
        # The footer goes to a session sonner started, once — on the first
        # ring it gets, whether that ring spawned it or a --wake did earlier.
        rec = _spawned_by_sonner(target.pid) or _adopt_pending(target)
        owed = bool(rec) and not rec.get("told") and bool(rec.get("errand") or args.errand)
        errand = _ERRAND_FOOTER if owed else None
        body = "\n\n".join(part for part in (args.message, footer, errand, stamp) if part)
        # Only a caller with no inbox of its own trades its from address for a
        # receipt socket; a session caller keeps its name, so replies route.
        receipt = deliver(target.socket, body, display, from_addr, mode,
                          receipt_window=_RECEIPT_WINDOW if footer else None)
        if owed:
            _mark_told(target.pid)
        return receipt

    spawned = False
    if args.name:
        targets = by_name(args.name)
        if not targets:
            print(f"no session named {args.name!r} — reachable sessions:", file=sys.stderr)
            for s in live_sessions():
                print(f"  {s.name:<20} {s.cwd}", file=sys.stderr)
            return 1
        if len(targets) > 1:
            names = ", ".join(f"pid {s.pid} in {s.cwd}" for s in targets)
            print(f"{len(targets)} sessions named {args.name!r} ({names}) — cannot choose", file=sys.stderr)
            return 1
    else:
        repo = Path(args.repo).expanduser().resolve()
        if not repo.is_dir():
            print(f"not a directory: {repo}", file=sys.stderr)
            return 2

        _hold_repo_lock(repo)
        targets = sessions_in(repo)
        if not targets:
            deaf = [s for s in registered_alive_in(repo) if s.socket is None]
            if deaf and not args.force_spawn:
                for s in deaf:
                    print(
                        f"live but deaf: {s.name} (pid {s.pid}) in {s.cwd} — no inbox exists, "
                        "so this message cannot be delivered, and spawning would plant a "
                        "sibling beside a busy session. Reach it another way (tmux attach, "
                        "or a file it will read), or pass --force-spawn to plant a sibling "
                        "that CAN receive this message.",
                        file=sys.stderr,
                    )
                return 1
            for s in deaf:
                print(
                    f"live but deaf: {s.name} (pid {s.pid}) in {s.cwd} — spawning a sibling "
                    "beside it as asked (--force-spawn); the deaf session does not see this message",
                    file=sys.stderr,
                )
            if args.no_spawn:
                print(f"no session in {repo} and --no-spawn given", file=sys.stderr)
                return 1
            print(f"no session in {repo} — starting one", file=sys.stderr)
            try:
                targets = [spawn(repo, work=args.work, errand=args.errand)]
            except HeldAtTrust as held:
                held.message = True
                receipt = send(held.session) if held.session is not None else None
                if receipt and receipt["status"] not in ("held", "delivered"):
                    print(f"{receipt['status']}: {held.session.name} (pid {held.session.pid}) in "
                          f"{repo} did not take the message ({receipt.get('reason') or 'no reason given'}); "
                          "it is also parked at the folder-trust dialog", file=sys.stderr)
                    return 1
                _say_held(held, delivered=held.session is not None)
                return 3
            spawned = True
        elif not args.all:
            targets = pick(targets, repo)

    status = 0
    for s in targets:
        receipt = send(s)
        where = f"{s.name} (pid {s.pid}) in {s.cwd}"
        if receipt is None:
            how = "woke" if spawned else "rang"
            # Silence is not proof: a slow session.receive hook, or a busy
            # receiver, can answer after the window — so say what was seen.
            seen = (f" — no hold or refusal came back within {_RECEIPT_WINDOW:.0f}s" if footer
                    else " — its gate's answer comes back only to a script ring")
            print(f"{how} {where}{seen}")
            continue
        state, reason = receipt["status"], receipt.get("reason") or "no reason given"
        if state == "held":
            print(f"held: {where} is holding the message for its user's approval ({reason}) — "
                  "it waits there, so do not ring again", file=sys.stderr)
            status = status or 3
        elif state == "delivered":
            print(f"rang {where}")
        else:
            print(f"{state}: {where} did not take the message ({reason})", file=sys.stderr)
            status = 1  # a lost message outranks a waiting one under --all
    return status


if __name__ == "__main__":
    sys.exit(main())
